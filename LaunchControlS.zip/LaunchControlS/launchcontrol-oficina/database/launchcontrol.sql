CREATE DATABASE IF NOT EXISTS launchcontrol CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE launchcontrol;
-- O Hibernate cria e atualiza as tabelas com spring.jpa.hibernate.ddl-auto=update.
-- Este arquivo prepara o banco. Não insira senhas manualmente: as contas demo são criadas
-- pelo DataSeeder e armazenadas com BCrypt na primeira inicialização.
