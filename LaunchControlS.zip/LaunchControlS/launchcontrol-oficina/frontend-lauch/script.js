/* =========================================================
   LaunchControl — script.js
   Protótipo com dados mockados e persistência em localStorage
   (ainda sem backend / API real).

   Pontos de integração futura com API/banco de dados real:
   - autenticarUsuario()        -> chamada de login (POST /auth/login)
   - salvarEstado()/carregarEstado() -> troca de localStorage por
     chamadas reais de leitura/escrita (GET/POST/PUT em endpoints)
   - envio de orçamento, aprovação/recusa -> endpoints dedicados
   ========================================================= */

// =========================================================
// 0. CHAVES DE ARMAZENAMENTO (localStorage)
// =========================================================
const LS_KEYS = {
  SESSAO: "lc_sessao",
  SOLICITACOES: "lc_solicitacoes",
  CLIENTES: "lc_clientes",
  OFICINAS: "lc_oficinas",
  CONFIG: "lc_config",
  NOTIFICACOES: "lc_notificacoes"
};

// =========================================================
// 1. DADOS MOCKADOS (seed inicial — usado apenas se o
//    localStorage ainda estiver vazio)
// =========================================================

// ---- Usuários da OFICINA (login tipo "oficina") ----
const OFICINAS_SEED = [
  { cpf: "11111111111", senha: "123456", nome: "Carlos Mendes", cargo: "Atendente" },
  { cpf: "77777777777", senha: "123456", nome: "Patrícia Nogueira", cargo: "Gerente" }
];

// ---- Clientes finais da oficina (login tipo "cliente") ----
const CLIENTES_SEED = [
  {
    cpf: "22222222222", senha: "123456", nome: "João Silva",
    telefone: "(11) 98765-4321", email: "joao.silva@email.com",
    veiculos: [
      { modelo: "Honda Civic", ano: 2020, placa: "ABC1D23", km: "42.300 km" }
    ]
  },
  {
    cpf: "33333333333", senha: "123456", nome: "Mariana Souza",
    telefone: "(11) 91234-5678", email: "mariana.souza@email.com",
    veiculos: [
      { modelo: "Fiat Argo", ano: 2022, placa: "DEF4E56", km: "18.900 km" },
      { modelo: "Hyundai HB20", ano: 2021, placa: "HJK7L89", km: "31.200 km" }
    ]
  },
  {
    cpf: "44444444444", senha: "123456", nome: "Ricardo Alves",
    telefone: "(11) 99887-6655", email: "ricardo.alves@email.com",
    veiculos: [
      { modelo: "Chevrolet Onix", ano: 2019, placa: "GHI9J01", km: "63.500 km" },
      { modelo: "Toyota Corolla", ano: 2023, placa: "MNO2P34", km: "9.400 km" }
    ]
  },
  {
    cpf: "55555555555", senha: "123456", nome: "Fernanda Lima",
    telefone: "(11) 97777-2233", email: "fernanda.lima@email.com",
    veiculos: [
      { modelo: "Volkswagen Gol", ano: 2018, placa: "QRS5T67", km: "78.100 km" }
    ]
  }
];

// ---- Solicitações de orçamento (ligadas a um cliente via clienteId = CPF) ----
const SOLICITACOES_SEED = [
  {
    id: 101,
    clienteId: "22222222222",
    cliente: "João Silva",
    telefone: "(11) 98765-4321",
    veiculo: "Honda Civic",
    ano: 2020,
    km: "42.300 km",
    servico: "Troca de pastilhas de freio",
    descricao: "Barulho ao frear e pedal um pouco mais fundo que o normal.",
    data: "17/08/2026",
    fotos: 2,
    status: "aprovacao", // orçamento já elaborado, aguardando resposta do cliente
    orcamento: {
      servico: "Revisão do veículo",
      descricao: "Revisão preventiva com troca de peças de desgaste.",
      pecas: [
        { id: 1, nome: "Pastilhas de freio dianteiras", descricao: "", quantidade: 1, valorUnitario: 280, total: 280, aprovado: null },
        { id: 2, nome: "Óleo do motor 5W30", descricao: "", quantidade: 4, valorUnitario: 45, total: 180, aprovado: null },
        { id: 3, nome: "Filtro de óleo", descricao: "", quantidade: 1, valorUnitario: 35, total: 35, aprovado: null },
        { id: 4, nome: "Filtro de ar", descricao: "", quantidade: 1, valorUnitario: 65, total: 65, aprovado: null },
        { id: 5, nome: "Filtro de combustível", descricao: "", quantidade: 1, valorUnitario: 50, total: 50, aprovado: null }
      ],
      maoDeObra: [
        { id: 1, descricao: "Troca das pastilhas", quantidade: 1, valorUnitario: 100, total: 100, aprovado: null },
        { id: 2, descricao: "Troca de óleo e filtros", quantidade: 1, valorUnitario: 80, total: 80, aprovado: null }
      ],
      subtotalPecas: 610,
      subtotalMaoDeObra: 180,
      total: 790,
      valorAprovado: null,
      prazo: "2 horas",
      obs: "Recomendamos alinhamento na próxima visita."
    },
    entrada: null,
    previsao: null
  },
  {
    id: 102,
    clienteId: "33333333333",
    cliente: "Mariana Souza",
    telefone: "(11) 91234-5678",
    veiculo: "Fiat Argo",
    ano: 2022,
    km: "18.900 km",
    servico: "Revisão dos 20.000 km",
    descricao: "Revisão programada de acordo com o manual do fabricante.",
    data: "16/08/2026",
    fotos: 0,
    status: "analise", // em análise pela oficina — ainda sem orçamento
    orcamento: null,
    entrada: null,
    previsao: null
  },
  {
    id: 103,
    clienteId: "44444444444",
    cliente: "Ricardo Alves",
    telefone: "(11) 99887-6655",
    veiculo: "Chevrolet Onix",
    ano: 2019,
    km: "63.500 km",
    servico: "Troca de amortecedores",
    descricao: "Carro balançando muito em lombadas e buracos.",
    data: "15/08/2026",
    fotos: 3,
    status: "aprovacao",
    orcamento: {
      servico: "Troca de amortecedores dianteiros",
      descricao: "Substituição do par de amortecedores dianteiros e alinhamento.",
      pecas: [
        { id: 1, nome: "Amortecedores dianteiros (par)", descricao: "", quantidade: 1, valorUnitario: 480, total: 480, aprovado: null }
      ],
      maoDeObra: [
        { id: 1, descricao: "Troca dos amortecedores e alinhamento", quantidade: 1, valorUnitario: 220, total: 220, aprovado: null }
      ],
      subtotalPecas: 480,
      subtotalMaoDeObra: 220,
      total: 700,
      valorAprovado: null,
      prazo: "3 horas",
      obs: "Recomendado alinhamento e balanceamento após a troca."
    },
    entrada: null,
    previsao: null
  },
  {
    id: 104,
    clienteId: "55555555555",
    cliente: "Fernanda Lima",
    telefone: "(11) 97777-2233",
    veiculo: "Volkswagen Gol",
    ano: 2018,
    km: "78.100 km",
    servico: "Troca de correia dentada",
    descricao: "Manutenção preventiva indicada pelo manual do veículo.",
    data: "12/08/2026",
    fotos: 1,
    status: "execucao",
    orcamento: {
      servico: "Troca de correia dentada e tensor",
      descricao: "Substituição da correia dentada, tensor e bomba d'água.",
      pecas: [
        { id: 1, nome: "Kit correia dentada", descricao: "", quantidade: 1, valorUnitario: 250, total: 250, aprovado: true },
        { id: 2, nome: "Bomba d'água", descricao: "", quantidade: 1, valorUnitario: 140, total: 140, aprovado: true }
      ],
      maoDeObra: [
        { id: 1, descricao: "Substituição da correia, tensor e bomba d'água", quantidade: 1, valorUnitario: 260, total: 260, aprovado: true }
      ],
      subtotalPecas: 390,
      subtotalMaoDeObra: 260,
      total: 650,
      valorAprovado: 650,
      prazo: "4 horas",
      obs: ""
    },
    entrada: "13/08/2026",
    previsao: "18/08/2026"
  },
  {
    id: 105,
    clienteId: "33333333333",
    cliente: "Mariana Souza",
    telefone: "(11) 91234-5678",
    veiculo: "Hyundai HB20",
    ano: 2021,
    km: "31.200 km",
    servico: "Troca de óleo e filtros",
    descricao: "Troca de óleo do motor e filtros de óleo e ar.",
    data: "08/08/2026",
    fotos: 0,
    status: "concluido",
    orcamento: {
      servico: "Troca de óleo e filtros",
      descricao: "Óleo sintético 5W30 + filtro de óleo e filtro de ar.",
      pecas: [
        { id: 1, nome: "Óleo 5W30", descricao: "", quantidade: 4, valorUnitario: 45, total: 180, aprovado: true },
        { id: 2, nome: "Filtro de óleo", descricao: "", quantidade: 1, valorUnitario: 30, total: 30, aprovado: true }
      ],
      maoDeObra: [
        { id: 1, descricao: "Troca de óleo e filtros", quantidade: 1, valorUnitario: 60, total: 60, aprovado: true }
      ],
      subtotalPecas: 210,
      subtotalMaoDeObra: 60,
      total: 270,
      valorAprovado: 270,
      prazo: "1 hora",
      obs: ""
    },
    entrada: "08/08/2026",
    previsao: "08/08/2026"
  },
  {
    id: 106,
    clienteId: "44444444444",
    cliente: "Ricardo Alves",
    telefone: "(11) 99887-6655",
    veiculo: "Toyota Corolla",
    ano: 2023,
    km: "9.400 km",
    servico: "Diagnóstico de luz no painel",
    descricao: "Luz de injeção eletrônica acesa no painel intermitentemente.",
    data: "17/08/2026",
    fotos: 1,
    status: "aguardando",
    orcamento: null,
    entrada: null,
    previsao: null
  }
];

// =========================================================
// 2. ESTADO EM MEMÓRIA (carregado do localStorage ou do seed)
// =========================================================
let oficinas = [];
let clientes = [];
let solicitacoes = [];
let notificacoes = [];
let sessao = null; // { tipo: 'oficina'|'cliente', cpf, nome, ... }

function carregarEstado(){
  oficinas = lerLS(LS_KEYS.OFICINAS, OFICINAS_SEED);
  clientes = lerLS(LS_KEYS.CLIENTES, CLIENTES_SEED);
  solicitacoes = lerLS(LS_KEYS.SOLICITACOES, SOLICITACOES_SEED);
  sessao = lerLS(LS_KEYS.SESSAO, null);
  notificacoes = lerLS(LS_KEYS.NOTIFICACOES, []);
  carregarConfig();
  atualizarIndicadoresNotificacao();
}

function lerLS(chave, padrao){
  try{
    const bruto = localStorage.getItem(chave);
    if (!bruto) return JSON.parse(JSON.stringify(padrao));
    return JSON.parse(bruto);
  }catch(e){
    return JSON.parse(JSON.stringify(padrao));
  }
}

function salvarSolicitacoes(){
  // Futuro: PUT /solicitacoes (ou por item) em vez de localStorage.
  localStorage.setItem(LS_KEYS.SOLICITACOES, JSON.stringify(solicitacoes));
}
function salvarClientes(){
  localStorage.setItem(LS_KEYS.CLIENTES, JSON.stringify(clientes));
}
function salvarOficinas(){
  localStorage.setItem(LS_KEYS.OFICINAS, JSON.stringify(oficinas));
}
function salvarSessao(){
  if (sessao) localStorage.setItem(LS_KEYS.SESSAO, JSON.stringify(sessao));
  else localStorage.removeItem(LS_KEYS.SESSAO);
}

const STATUS_INFO = {
  aguardando:       { label: "Aguardando análise",             cls: "status--aguardando" },
  analise:          { label: "Em análise",                     cls: "status--analise" },
  aprovacao:        { label: "Aguardando aprovação do cliente", cls: "status--aprovacao" },
  aprovado:         { label: "Aprovado pelo cliente",           cls: "status--aprovado" },
  aprovado_parcial: { label: "Aprovado parcialmente",           cls: "status--aprovacao" },
  execucao:         { label: "Em execução",                     cls: "status--execucao" },
  concluido:        { label: "Concluído",                       cls: "status--concluido" },
  recusado:         { label: "Recusado pela oficina",           cls: "status--recusado" },
  recusado_cliente: { label: "Recusado pelo cliente",           cls: "status--recusado" }
};

function formatBRL(v){
  return (v || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}
function statusBadge(statusKey){
  const s = STATUS_INFO[statusKey] || { label: statusKey, cls: "status--aguardando" };
  return `<span class="status ${s.cls}">${s.label}</span>`;
}
function iniciais(nome){
  return (nome || "").split(" ").filter(Boolean).slice(0,2).map(p => p[0].toUpperCase()).join("");
}

// =========================================================
// 3. AUTENTICAÇÃO (simulada)
// =========================================================

// Validação simplificada de CPF: exige 11 dígitos numéricos.
// OBS: os CPFs de teste usados neste protótipo (111.111.111-11 etc.)
// são sequências repetidas e não passariam no algoritmo oficial
// (módulo 11), por isso a checagem aqui fica no nível de formato.
// Ponto de integração futura: plugar validação completa (mod 11)
// quando os CPFs deixarem de ser mockados.
function apenasDigitos(v){ return (v || "").replace(/\D/g, ""); }

function cpfValido(cpfDigits){
  if (cpfDigits.length !== 11) return false;
  return true;
}

function mascararCpf(valor){
  let d = apenasDigitos(valor).slice(0, 11);
  if (d.length > 9) return d.replace(/(\d{3})(\d{3})(\d{3})(\d{1,2})/, "$1.$2.$3-$4");
  if (d.length > 6) return d.replace(/(\d{3})(\d{3})(\d{1,3})/, "$1.$2.$3");
  if (d.length > 3) return d.replace(/(\d{3})(\d{1,3})/, "$1.$2");
  return d;
}

function mascararTelefone(valor){
  let d = apenasDigitos(valor).slice(0, 11);
  if (d.length > 10) return d.replace(/(\d{2})(\d{5})(\d{4})/, "($1) $2-$3");
  if (d.length > 6) return d.replace(/(\d{2})(\d{4})(\d{1,4})/, "($1) $2-$3");
  if (d.length > 2) return d.replace(/(\d{2})(\d{1,5})/, "($1) $2");
  if (d.length > 0) return d.replace(/(\d{1,2})/, "($1");
  return d;
}

function emailValido(email){
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function cpfJaCadastrado(cpfDigits){
  return oficinas.some(o => o.cpf === cpfDigits) || clientes.some(c => c.cpf === cpfDigits);
}

function cadastrarUsuario(tipo, dados){
  // Futuro: substituir por chamada real, ex.
  // POST /auth/cadastro { tipo, ...dados } -> { token, usuario }
  if (cpfJaCadastrado(dados.cpf)){
    return { ok: false, motivo: "Já existe uma conta cadastrada com esse CPF." };
  }
  if (tipo === "oficina"){
    const novaOficina = {
      cpf: dados.cpf,
      senha: dados.senha,
      nome: dados.nome,
      cargo: dados.cargo || "Atendente"
    };
    oficinas.push(novaOficina);
    salvarOficinas();
    return { ok: true, usuario: novaOficina };
  } else {
    const novoCliente = {
      cpf: dados.cpf,
      senha: dados.senha,
      nome: dados.nome,
      telefone: dados.telefone,
      email: dados.email,
      veiculos: []
    };
    clientes.push(novoCliente);
    salvarClientes();
    return { ok: true, usuario: novoCliente };
  }
}

function autenticarUsuario(tipo, cpfDigits, senha){
  // Futuro: substituir por chamada real, ex.
  // POST /auth/login { tipo, cpf, senha } -> { token, usuario }
  if (tipo === "oficina"){
    const u = oficinas.find(o => o.cpf === cpfDigits);
    if (!u) return { ok: false, motivo: "CPF não encontrado para oficina." };
    if (u.senha !== senha) return { ok: false, motivo: "Senha incorreta." };
    return { ok: true, usuario: u };
  } else {
    const u = clientes.find(c => c.cpf === cpfDigits);
    if (!u) return { ok: false, motivo: "CPF não encontrado para cliente." };
    if (u.senha !== senha) return { ok: false, motivo: "Senha incorreta." };
    return { ok: true, usuario: u };
  }
}

function iniciarSessao(tipo, usuario){
  sessao = { tipo, cpf: usuario.cpf, nome: usuario.nome };
  salvarSessao();
  atualizarIndicadoresNotificacao();
}
function encerrarSessao(){
  sessao = null;
  salvarSessao();
  mostrarTelaInicio();
}

const TELAS_PRINCIPAIS = ["telaInicio", "telaLogin", "telaCadastro", "telaSobreNos", "telaLGPD", "telaMapaSite", "appOficina", "appCliente"];

function esconderTodasAsTelas(){
  TELAS_PRINCIPAIS.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = "none";
  });
}

function mostrarTelaInicio(){
  esconderTodasAsTelas();
  document.getElementById("telaInicio").style.display = "block";
  window.scrollTo(0, 0);
}

function mostrarTelaLogin(){
  esconderTodasAsTelas();
  document.getElementById("telaLogin").style.display = "flex";
  document.getElementById("formLogin").reset();
  document.getElementById("loginCpf").value = "";
  document.getElementById("erroLogin").textContent = "";
  document.getElementById("erroCpf").textContent = "";
  document.getElementById("erroSenha").textContent = "";
}

function mostrarTelaCadastro(){
  esconderTodasAsTelas();
  document.getElementById("telaCadastro").style.display = "flex";
  document.getElementById("formCadastro").reset();
  document.getElementById("cadastroTipo").value = "cliente";
  document.querySelectorAll("#tipoCadastroSeg .segmented__opt").forEach(b =>
    b.classList.toggle("is-active", b.dataset.tipo === "cliente"));
  atualizarCamposCadastro("cliente");
  ["erroCadastroNome","erroCadastroCpf","erroCadastroTelefone","erroCadastroEmail",
   "erroCadastroCargo","erroCadastroSenha","erroCadastroConfirmarSenha","erroCadastro"]
    .forEach(id => document.getElementById(id).textContent = "");
}

function mostrarTelaSobreNos(){
  esconderTodasAsTelas();
  document.getElementById("telaSobreNos").style.display = "block";
  window.scrollTo(0, 0);
}

function mostrarTelaLGPD(){
  esconderTodasAsTelas();
  document.getElementById("telaLGPD").style.display = "block";
  window.scrollTo(0, 0);
}

function mostrarTelaMapaSite(){
  esconderTodasAsTelas();
  document.getElementById("telaMapaSite").style.display = "block";
  window.scrollTo(0, 0);
}

// Roteamento das páginas públicas (Sobre Nós, LGPD, Mapa do Site, Login, Cadastro):
// qualquer link com atributo data-goto navega dentro do próprio SPA, sem recarregar
// a página e sem perder o estado da sessão.
document.addEventListener("click", (e) => {
  const link = e.target.closest("[data-goto]");
  if (!link) return;
  e.preventDefault();
  const destino = link.dataset.goto;
  const rotas = {
    "inicio": mostrarTelaInicio,
    "login": mostrarTelaLogin,
    "cadastro": mostrarTelaCadastro,
    "sobre-nos": mostrarTelaSobreNos,
    "lgpd": mostrarTelaLGPD,
    "mapa-site": mostrarTelaMapaSite
  };
  if (rotas[destino]) rotas[destino]();
  // atalhos da home: "Entrar como cliente/oficina" já deixam o tipo selecionado
  if (destino === "login" && link.dataset.tipo){
    const opt = document.querySelector(`#tipoUsuarioSeg [data-tipo="${link.dataset.tipo}"]`);
    if (opt) opt.click();
  }
});

function atualizarCamposCadastro(tipo){
  const ehOficina = tipo === "oficina";
  document.getElementById("campoCadastroCargo").style.display = ehOficina ? "flex" : "none";
  document.getElementById("campoCadastroTelefone").style.display = ehOficina ? "none" : "flex";
  document.getElementById("campoCadastroEmail").style.display = ehOficina ? "none" : "flex";
}

function entrarComoOficina(usuario){
  esconderTodasAsTelas();
  document.getElementById("appCliente").style.display = "none";
  document.getElementById("appOficina").style.display = "block";
  document.getElementById("oficinaNome").textContent = usuario.nome;
  document.getElementById("oficinaCargo").textContent = usuario.cargo || "Atendente";
  document.getElementById("oficinaAvatar").textContent = iniciais(usuario.nome);
  goToView("dashboard");
}

function entrarComoCliente(usuario){
  esconderTodasAsTelas();
  document.getElementById("appOficina").style.display = "none";
  document.getElementById("appCliente").style.display = "block";
  document.getElementById("cliNomeTopo").textContent = usuario.nome;
  document.getElementById("cliNomeSaudacao").textContent = (usuario.nome || "").split(" ")[0];
  document.getElementById("cliAvatar").textContent = iniciais(usuario.nome);
  goToViewCli("dashboard");
}

function restaurarSessaoSeExistir(){
  if (!sessao) { mostrarTelaInicio(); return; }
  if (sessao.tipo === "oficina"){
    const u = oficinas.find(o => o.cpf === sessao.cpf);
    if (u) { entrarComoOficina(u); return; }
  } else if (sessao.tipo === "cliente"){
    const u = clientes.find(c => c.cpf === sessao.cpf);
    if (u) { entrarComoCliente(u); return; }
  }
  // sessão inválida/corrompida
  encerrarSessao();
}

// ---- Eventos da tela de login ----
document.getElementById("tipoUsuarioSeg").addEventListener("click", (e) => {
  const btn = e.target.closest(".segmented__opt");
  if (!btn) return;
  document.querySelectorAll(".segmented__opt").forEach(b => b.classList.remove("is-active"));
  btn.classList.add("is-active");
  document.getElementById("loginTipo").value = btn.dataset.tipo;
});

document.getElementById("loginCpf").addEventListener("input", (e) => {
  e.target.value = mascararCpf(e.target.value);
});

document.getElementById("btnEsqueciSenha").addEventListener("click", () => {
  document.getElementById("recuperarMensagem").textContent = "";
  document.getElementById("modalRecuperarSenha").classList.add("is-open");
});
document.getElementById("closeRecuperarSenha").addEventListener("click", fecharRecuperacao);
document.getElementById("cancelarRecuperacao").addEventListener("click", fecharRecuperacao);
document.getElementById("recuperarCpf").addEventListener("input", e => e.target.value = mascararCpf(e.target.value));
document.getElementById("formRecuperarSenha").addEventListener("submit", e => {
  e.preventDefault();
  const cpf = apenasDigitos(document.getElementById("recuperarCpf").value);
  const email = document.getElementById("recuperarEmail").value.trim().toLowerCase();
  const conta = [...clientes, ...oficinas].find(u => u.cpf === cpf && (u.email || "").toLowerCase() === email);
  const msg = document.getElementById("recuperarMensagem");
  // Resposta neutra para não revelar a existência de contas. O envio real exige backend SMTP.
  msg.textContent = "Se os dados corresponderem a uma conta, as instruções serão enviadas ao e-mail cadastrado. O envio ainda depende da configuração do backend SMTP.";
});
function fecharRecuperacao(){ document.getElementById("modalRecuperarSenha").classList.remove("is-open"); }

document.getElementById("formLogin").addEventListener("submit", (e) => {
  e.preventDefault();
  const tipo = document.getElementById("loginTipo").value;
  const cpfDigits = apenasDigitos(document.getElementById("loginCpf").value);
  const senha = document.getElementById("loginSenha").value;

  const erroCpfEl = document.getElementById("erroCpf");
  const erroSenhaEl = document.getElementById("erroSenha");
  const erroLoginEl = document.getElementById("erroLogin");
  erroCpfEl.textContent = "";
  erroSenhaEl.textContent = "";
  erroLoginEl.textContent = "";

  let temErro = false;
  if (!cpfValido(cpfDigits)){
    erroCpfEl.textContent = "Informe um CPF válido no formato 000.000.000-00.";
    temErro = true;
  }
  if (!senha || senha.length < 4){
    erroSenhaEl.textContent = "Informe sua senha.";
    temErro = true;
  }
  if (temErro) return;

  const resultado = autenticarUsuario(tipo, cpfDigits, senha);
  if (!resultado.ok){
    erroLoginEl.textContent = resultado.motivo;
    return;
  }

  iniciarSessao(tipo, resultado.usuario);
  if (tipo === "oficina") entrarComoOficina(resultado.usuario);
  else entrarComoCliente(resultado.usuario);
  mostrarToast(`Bem-vindo(a), ${resultado.usuario.nome.split(" ")[0]}!`);
});

document.getElementById("btnLogoutOficina").addEventListener("click", encerrarSessao);
document.getElementById("btnLogoutCliente").addEventListener("click", encerrarSessao);

// ---- Eventos da tela de cadastro ----
document.getElementById("btnIrParaCadastro").addEventListener("click", mostrarTelaCadastro);
document.getElementById("btnVoltarParaLogin").addEventListener("click", mostrarTelaLogin);

document.getElementById("tipoCadastroSeg").addEventListener("click", (e) => {
  const btn = e.target.closest(".segmented__opt");
  if (!btn) return;
  document.querySelectorAll("#tipoCadastroSeg .segmented__opt").forEach(b => b.classList.remove("is-active"));
  btn.classList.add("is-active");
  document.getElementById("cadastroTipo").value = btn.dataset.tipo;
  atualizarCamposCadastro(btn.dataset.tipo);
});

document.getElementById("cadastroCpf").addEventListener("input", (e) => {
  e.target.value = mascararCpf(e.target.value);
});
document.getElementById("cadastroTelefone").addEventListener("input", (e) => {
  e.target.value = mascararTelefone(e.target.value);
});

document.getElementById("formCadastro").addEventListener("submit", (e) => {
  e.preventDefault();
  const tipo = document.getElementById("cadastroTipo").value;
  const nome = document.getElementById("cadastroNome").value.trim();
  const cpfDigits = apenasDigitos(document.getElementById("cadastroCpf").value);
  const telefone = document.getElementById("cadastroTelefone").value.trim();
  const email = document.getElementById("cadastroEmail").value.trim();
  const cargo = document.getElementById("cadastroCargo").value.trim();
  const senha = document.getElementById("cadastroSenha").value;
  const confirmarSenha = document.getElementById("cadastroConfirmarSenha").value;

  const erros = {
    erroCadastroNome: "", erroCadastroCpf: "", erroCadastroTelefone: "",
    erroCadastroEmail: "", erroCadastroCargo: "", erroCadastroSenha: "",
    erroCadastroConfirmarSenha: "", erroCadastro: ""
  };

  let temErro = false;
  if (!nome || nome.length < 3){
    erros.erroCadastroNome = "Informe seu nome completo.";
    temErro = true;
  }
  if (!cpfValido(cpfDigits)){
    erros.erroCadastroCpf = "Informe um CPF válido no formato 000.000.000-00.";
    temErro = true;
  }
  if (tipo === "cliente"){
    if (apenasDigitos(telefone).length < 10){
      erros.erroCadastroTelefone = "Informe um telefone válido com DDD.";
      temErro = true;
    }
    if (!emailValido(email)){
      erros.erroCadastroEmail = "Informe um e-mail válido.";
      temErro = true;
    }
  }
  if (!senha || senha.length < 6){
    erros.erroCadastroSenha = "A senha deve ter no mínimo 6 caracteres.";
    temErro = true;
  }
  if (senha !== confirmarSenha){
    erros.erroCadastroConfirmarSenha = "As senhas não coincidem.";
    temErro = true;
  }

  Object.keys(erros).forEach(id => document.getElementById(id).textContent = erros[id]);
  if (temErro) return;

  const resultado = cadastrarUsuario(tipo, { nome, cpf: cpfDigits, telefone, email, cargo, senha });
  if (!resultado.ok){
    document.getElementById("erroCadastro").textContent = resultado.motivo;
    return;
  }

  iniciarSessao(tipo, resultado.usuario);
  if (tipo === "oficina") entrarComoOficina(resultado.usuario);
  else entrarComoCliente(resultado.usuario);
  mostrarToast(`Conta criada com sucesso! Bem-vindo(a), ${resultado.usuario.nome.split(" ")[0]}!`);
});

// =========================================================
// CENTRAL DE NOTIFICAÇÕES (persistência local do protótipo)
// =========================================================
function salvarNotificacoes(){ localStorage.setItem(LS_KEYS.NOTIFICACOES, JSON.stringify(notificacoes)); }
function criarNotificacao({ destinatario, tipo, titulo, mensagem, solicitacaoId, evento }){
  if (!destinatario || notificacoes.some(n => n.evento === evento && n.destinatario === destinatario)) return;
  notificacoes.unshift({ id: "N" + Date.now() + Math.random().toString(16).slice(2,6), destinatario, tipo, titulo, mensagem, solicitacaoId, evento, data: new Date().toISOString(), lida: false });
  salvarNotificacoes(); atualizarIndicadoresNotificacao();
}
function notificarCompra(s, evento, titulo, status){
  const valor = s.pagamento?.valor ?? s.orcamento?.valorAprovado ?? s.orcamento?.total ?? 0;
  const protocolo = s.pagamento?.protocolo || `LC-${s.id}`;
  const quando = new Date().toLocaleString("pt-BR");
  const texto = `${s.orcamento?.servico || s.servico} • ${formatBRL(valor)} • ${status} • Pedido ${protocolo} • ${quando}`;
  criarNotificacao({ destinatario: `cliente:${s.clienteId}`, tipo:"cliente", titulo, mensagem:texto, solicitacaoId:s.id, evento });
  const oficinaDestino = s.oficinaId || oficinas[0]?.cpf;
  if (oficinaDestino) criarNotificacao({ destinatario:`oficina:${oficinaDestino}`, tipo:"oficina", titulo:"Atualização de compra de cliente", mensagem:`${s.cliente} — ${texto}`, solicitacaoId:s.id, evento });
}
function notificacoesDoUsuario(){
  if (!sessao) return [];
  return notificacoes.filter(n => n.destinatario === `${sessao.tipo}:${sessao.cpf}`);
}
function atualizarIndicadoresNotificacao(){
  const naoLidas = notificacoesDoUsuario().filter(n => !n.lida).length;
  ["notifBadge","notifBadgeCliente"].forEach(id => { const el=document.getElementById(id); if(el){el.textContent=naoLidas;el.style.display=naoLidas?"flex":"none";} });
  ["navNotifCount","navNotifCountCliente"].forEach(id => { const el=document.getElementById(id); if(el) el.textContent=naoLidas?`(${naoLidas})`:""; });
}
function renderNotificacoes(){
  const lista=notificacoesDoUsuario();
  const html=lista.length?lista.map(n=>`<article class="notification-item ${n.lida?"is-read":"is-unread"}"><div class="notification-item__main"><strong>${escapeHtml(n.titulo)}</strong><p>${escapeHtml(n.mensagem)}</p><small>${new Date(n.data).toLocaleString("pt-BR")}</small></div><div class="notification-item__actions">${!n.lida?`<button class="btn btn--outline btnNotifLer" data-id="${n.id}">Marcar como lida</button>`:"<span class='notification-read-label'>Lida</span>"}<button class="btn btn--outline btnNotifDetalhe" data-id="${n.id}">Ver pedido</button><button class="btn btn--ghost btnNotifExcluir" data-id="${n.id}" aria-label="Excluir">Excluir</button></div></article>`).join(""):`<p class="notification-empty">Você ainda não possui notificações.</p>`;
  ["listaNotificacoesOficina","listaNotificacoesCliente"].forEach(id=>{const el=document.getElementById(id);if(el)el.innerHTML=html;});
  atualizarIndicadoresNotificacao();
}
function escapeHtml(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function marcarTodasNotificacoes(){notificacoesDoUsuario().forEach(n=>n.lida=true);salvarNotificacoes();renderNotificacoes();}
document.addEventListener("click",e=>{
  const ler=e.target.closest(".btnNotifLer"); const excluir=e.target.closest(".btnNotifExcluir"); const detalhe=e.target.closest(".btnNotifDetalhe");
  if(ler){const n=notificacoes.find(x=>x.id===ler.dataset.id && sessao && x.destinatario===`${sessao.tipo}:${sessao.cpf}`);if(n){n.lida=true;salvarNotificacoes();renderNotificacoes();}}
  if(excluir){notificacoes=notificacoes.filter(x=>!(x.id===excluir.dataset.id && sessao && x.destinatario===`${sessao.tipo}:${sessao.cpf}`));salvarNotificacoes();renderNotificacoes();}
  if(detalhe){const n=notificacoes.find(x=>x.id===detalhe.dataset.id && sessao && x.destinatario===`${sessao.tipo}:${sessao.cpf}`);if(n){n.lida=true;salvarNotificacoes();renderNotificacoes();if(sessao.tipo==="cliente")abrirDetalheCliente(n.solicitacaoId);else abrirDetalhe(n.solicitacaoId);}}
});
["btnMarcarTodasLidas","btnMarcarTodasLidasCliente"].forEach(id=>{const el=document.getElementById(id);if(el)el.addEventListener("click",marcarTodasNotificacoes);});

// =========================================================
// 4. NAVEGAÇÃO — PAINEL DA OFICINA
// =========================================================
document.querySelectorAll(".nav-link, .link-more").forEach(link => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    goToView(link.dataset.view);
  });
});

function goToView(viewName){
  document.querySelectorAll("#appOficina .view").forEach(v => v.classList.remove("is-active"));
  const alvo = document.getElementById(`view-${viewName}`);
  if (alvo) alvo.classList.add("is-active");

  document.querySelectorAll(".nav-link").forEach(l => l.classList.remove("is-active"));
  const activeLink = document.querySelector(`.nav-link[data-view="${viewName}"]`);
  if (activeLink) activeLink.classList.add("is-active");

  if (viewName === "config") renderConfig();
  if (viewName === "notificacoes") renderNotificacoes();
  renderAll();
}

// =========================================================
// 5. NAVEGAÇÃO — PAINEL DO CLIENTE
// =========================================================
document.querySelectorAll(".nav-link-cli, .link-more-cli").forEach(link => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    goToViewCli(link.dataset.viewCli);
  });
});

function goToViewCli(viewName){
  document.querySelectorAll("#appCliente .view").forEach(v => v.classList.remove("is-active"));
  const alvo = document.getElementById(`viewcli-${viewName}`);
  if (alvo) alvo.classList.add("is-active");

  document.querySelectorAll(".nav-link-cli").forEach(l => l.classList.remove("is-active"));
  const activeLink = document.querySelector(`.nav-link-cli[data-view-cli="${viewName}"]`);
  if (activeLink) activeLink.classList.add("is-active");

  if (viewName === "notificacoes") renderNotificacoes();
  renderCliente();
}

// Helpers de permissão: solicitações do cliente logado
function solicitacoesDoCliente(){
  if (!sessao || sessao.tipo !== "cliente") return [];
  return solicitacoes.filter(s => s.clienteId === sessao.cpf);
}
function clienteAtual(){
  if (!sessao || sessao.tipo !== "cliente") return null;
  return clientes.find(c => c.cpf === sessao.cpf) || null;
}

// =========================================================
// 6. RENDERIZAÇÃO — PAINEL DA OFICINA
// =========================================================
function renderAll(){
  renderKpis();
  renderRequestList(document.getElementById("recentRequests"), solicitacoes.slice(0, 3));
  renderRequestList(document.getElementById("allRequests"), solicitacoes);
  renderOrcamentosTable();
  renderAndamentoTable();
  renderConcluidosTable();
  renderClientesTable();
  renderVeiculosTable();
}

function renderKpis(){
  const novas = solicitacoes.filter(s => s.status === "aguardando").length;
  const pendentes = solicitacoes.filter(s => s.status === "aprovacao" || s.status === "aprovado_parcial").length;
  const andamento = solicitacoes.filter(s => s.status === "execucao" || s.status === "aprovado").length;
  const concluidos = solicitacoes.filter(s => s.status === "concluido").length;

  const cards = [
    { label: "Novas solicitações", value: novas, icon: "📥", color: "var(--accent)" },
    { label: "Orçamentos pendentes", value: pendentes, icon: "🧾", color: "var(--amber)" },
    { label: "Serviços em andamento", value: andamento, icon: "🔧", color: "var(--purple)" },
    { label: "Serviços concluídos", value: concluidos, icon: "✅", color: "var(--teal)" }
  ];

  document.getElementById("kpiCards").innerHTML = cards.map(c => `
    <div class="kpi-card" style="--kpi-color:${c.color}">
      <span class="kpi-icon">${c.icon}</span>
      <div class="kpi-label">${c.label}</div>
      <div class="kpi-value">${c.value}</div>
    </div>
  `).join("");
}

function renderRequestList(container, list){
  if (!container) return;
  if (list.length === 0){
    container.innerHTML = `<p style="color:var(--ink-soft); padding:20px 0;">Nenhuma solicitação por aqui.</p>`;
    return;
  }
  container.innerHTML = list.map(s => `
    <div class="req-card">
      <div class="req-card__main">
        <div class="req-field"><span class="k">Cliente</span><span class="v">${s.cliente}</span></div>
        <div class="req-field"><span class="k">Veículo</span><span class="v">${s.veiculo} · ${s.ano}</span></div>
        <div class="req-field"><span class="k">Serviço</span><span class="v">${s.servico}</span></div>
        <div class="req-field"><span class="k">Data</span><span class="v mono">${s.data}</span></div>
      </div>
      <div>${statusBadge(s.status)}</div>
      <button class="btn btn--outline" data-detalhe="${s.id}">Visualizar</button>
    </div>
  `).join("");

  container.querySelectorAll("[data-detalhe]").forEach(btn => {
    btn.addEventListener("click", () => abrirDetalhe(Number(btn.dataset.detalhe)));
  });
}

function renderOrcamentosTable(){
  const tbody = document.querySelector("#orcamentosTable tbody");
  const comOrcamento = solicitacoes.filter(s => s.orcamento);
  if (comOrcamento.length === 0){
    tbody.innerHTML = `<tr><td colspan="5" style="color:var(--ink-soft); padding:24px 0;">Nenhum orçamento elaborado ainda.</td></tr>`;
    return;
  }
  tbody.innerHTML = comOrcamento.map(s => `
    <tr class="row-click" data-orc-detalhe="${s.id}">
      <td>${s.cliente}</td>
      <td>${s.veiculo}</td>
      <td>${s.orcamento.servico}</td>
      <td class="mono">${formatBRL(s.orcamento.total)}</td>
      <td>${statusBadge(s.status)}</td>
    </tr>
  `).join("");

  tbody.querySelectorAll("[data-orc-detalhe]").forEach(tr => {
    tr.addEventListener("click", () => abrirDetalheOrcamentoOficina(Number(tr.dataset.orcDetalhe)));
  });
}

function renderAndamentoTable(){
  const tbody = document.querySelector("#andamentoTable tbody");
  const emAndamento = solicitacoes.filter(s =>
    ["aprovacao", "aprovado_parcial", "aprovado", "execucao"].includes(s.status)
  );
  if (emAndamento.length === 0){
    tbody.innerHTML = `<tr><td colspan="6" style="color:var(--ink-soft); padding:24px 0;">Nenhum serviço em andamento.</td></tr>`;
    return;
  }
  tbody.innerHTML = emAndamento.map(s => `
    <tr>
      <td>${s.cliente}</td>
      <td>${s.veiculo}</td>
      <td>${s.servico}</td>
      <td class="mono">${s.entrada || "—"}</td>
      <td class="mono">${s.previsao || "—"}</td>
      <td>${statusBadge(s.status)}</td>
    </tr>
  `).join("");
}

function renderConcluidosTable(){
  const tbody = document.querySelector("#concluidosTable tbody");
  if (!tbody) return;
  const concluidos = solicitacoes.filter(s => s.status === "concluido");
  if (concluidos.length === 0){
    tbody.innerHTML = `<tr><td colspan="6" style="color:var(--ink-soft); padding:24px 0;">Nenhum serviço concluído ainda.</td></tr>`;
    return;
  }
  tbody.innerHTML = concluidos.map(s => `
    <tr>
      <td>${s.cliente}</td>
      <td>${s.veiculo}</td>
      <td>${s.servico}</td>
      <td class="mono">${s.data}</td>
      <td class="mono">${s.orcamento ? formatBRL(s.orcamento.total) : "—"}</td>
      <td>${pagamentoBadge(s)}</td>
    </tr>
  `).join("");
}

function renderClientesTable(){
  const tbody = document.querySelector("#clientesTable tbody");
  if (!tbody) return;
  if (clientes.length === 0){
    tbody.innerHTML = `<tr><td colspan="5" style="color:var(--ink-soft); padding:24px 0;">Nenhum cliente cadastrado.</td></tr>`;
    return;
  }
  tbody.innerHTML = clientes.map(c => `
    <tr>
      <td>${c.nome}</td>
      <td class="mono">${mascararCpf(c.cpf)}</td>
      <td class="mono">${c.telefone}</td>
      <td>${c.email}</td>
      <td>${c.veiculos.map(v => v.modelo).join(", ")}</td>
    </tr>
  `).join("");
}

function renderVeiculosTable(){
  const tbody = document.querySelector("#veiculosTable tbody");
  if (!tbody) return;
  const linhas = [];
  clientes.forEach(c => {
    c.veiculos.forEach(v => {
      const ultima = solicitacoes
        .filter(s => s.clienteId === c.cpf && s.veiculo === v.modelo)
        .sort((a,b) => (a.id < b.id ? 1 : -1))[0];
      linhas.push(`
        <tr>
          <td>${v.modelo} <span class="mono" style="color:var(--ink-soft)">(${v.placa})</span></td>
          <td>${v.ano}</td>
          <td>${c.nome}</td>
          <td>${ultima ? ultima.servico : "—"}</td>
        </tr>
      `);
    });
  });
  tbody.innerHTML = linhas.length
    ? linhas.join("")
    : `<tr><td colspan="4" style="color:var(--ink-soft); padding:24px 0;">Nenhum veículo cadastrado.</td></tr>`;
}

// =========================================================
// 7. MODAL: DETALHES DA SOLICITAÇÃO (oficina)
// =========================================================
const modalDetalhe = document.getElementById("modalDetalhe");
const modalOrcamento = document.getElementById("modalOrcamento");
const modalOrcamentoDetalheOficina = document.getElementById("modalOrcamentoDetalheOficina");
const modalDetalheCli = document.getElementById("modalDetalheCli");
const modalOrcamentoCliente = document.getElementById("modalOrcamentoCliente");
const modalCartao = document.getElementById("modalCartao");
const modalPagamento = document.getElementById("modalPagamento");
const modalFoto = document.getElementById("modalFoto");

function abrirDetalhe(id){
  const s = solicitacoes.find(x => x.id === id);
  if (!s) return;

  document.getElementById("detalheBody").innerHTML = `
    <div class="detail-grid">
      <div class="detail-item"><div class="k">Cliente</div><div class="v">${s.cliente}</div></div>
      <div class="detail-item"><div class="k">CPF</div><div class="v mono">${mascararCpf(s.clienteId)}</div></div>
      <div class="detail-item"><div class="k">Telefone</div><div class="v">${s.telefone}</div></div>
      <div class="detail-item"><div class="k">Veículo</div><div class="v">${s.veiculo}</div></div>
      <div class="detail-item"><div class="k">Ano</div><div class="v">${s.ano}</div></div>
      <div class="detail-item"><div class="k">Quilometragem</div><div class="v">${s.km}</div></div>
      <div class="detail-item"><div class="k">Data da solicitação</div><div class="v">${s.data}</div></div>
      <div class="detail-item full"><div class="k">Serviço solicitado</div><div class="v">${s.servico}</div></div>
      <div class="detail-item full"><div class="k">Descrição do problema</div><div class="v" style="font-weight:400;">${s.descricao}</div></div>
      <div class="detail-item full">
        <div class="k">Fotos do veículo / problema</div>
        <div class="photo-zone">${fotosBlocoHtml(s, false)}</div>
      </div>
      <div class="detail-item"><div class="k">Status atual</div><div class="v">${statusBadge(s.status)}</div></div>
    </div>
    <div class="modal__actions">
      <button type="button" class="btn btn--danger" id="btnRecusar">Recusar solicitação</button>
      ${s.status === "concluido" ? "" : `
      <button type="button" class="btn btn--primary" id="btnElaborarOrcamento">
        ${s.orcamento ? "Editar orçamento" : "Elaborar orçamento"}
      </button>`}
    </div>
  `;

  document.getElementById("btnRecusar").addEventListener("click", () => {
    if (["aprovado","aprovado_parcial","execucao","concluido"].includes(s.status)) { mostrarToast("Esta solicitação já avançou para serviço e não pode ser recusada."); return; }
    s.status = "recusado";
    s.historico = s.historico || [];
    s.historico.push({status:"recusado",data:new Date().toISOString(),ator:"oficina",descricao:"Solicitação recusada pela oficina"});
    notificarClienteDaSolicitacao?.(s,"Solicitação recusada","A oficina recusou sua solicitação.",`recusa-${s.id}`);
    salvarSolicitacoes();
    fecharModais();
    renderAll();
    mostrarToast(`Solicitação de ${s.cliente} foi recusada.`);
  });

  const btnElaborar = document.getElementById("btnElaborarOrcamento");
  if (btnElaborar){
    btnElaborar.addEventListener("click", () => {
      fecharModais();
      abrirOrcamento(s.id);
    });
  }

  ligarFotos(document.getElementById("detalheBody"), s, false, () => {});
  modalDetalhe.classList.add("is-open");
}

// =========================================================
// 8. MODAL: ELABORAR / EDITAR ORÇAMENTO (oficina)
//    — editor itemizado de peças e mão de obra
// =========================================================
let orcPecasTemp = [];
let orcMaoObraTemp = [];
let orcProximoIdPeca = 1;
let orcProximoIdMaoObra = 1;

function novoItemPeca(nome = "", descricao = "", quantidade = 1, valorUnitario = 0, aprovado = null){
  return { id: orcProximoIdPeca++, nome, descricao, quantidade, valorUnitario, aprovado };
}
function novoItemMaoObra(descricao = "", quantidade = 1, valorUnitario = 0, aprovado = null){
  return { id: orcProximoIdMaoObra++, descricao, quantidade, valorUnitario, aprovado };
}

function abrirOrcamento(id){
  const s = solicitacoes.find(x => x.id === id);
  if (!s) return;
  if (s.status === "concluido") return; // serviço concluído: orçamento não pode mais ser editado

  document.getElementById("orcSolicitacaoId").value = id;
  document.getElementById("orcModalTitulo").textContent = s.orcamento ? "Editar orçamento" : "Elaborar orçamento";

  orcProximoIdPeca = 1;
  orcProximoIdMaoObra = 1;

  if (s.orcamento){
    // modo edição: carrega itens já existentes
    document.getElementById("orcServico").value = s.orcamento.servico;
    document.getElementById("orcDescricao").value = s.orcamento.descricao || "";
    document.getElementById("orcPrazo").value = s.orcamento.prazo || "";
    document.getElementById("orcObs").value = s.orcamento.obs || "";
    orcPecasTemp = s.orcamento.pecas.map(p => ({ ...p, id: orcProximoIdPeca++ }));
    orcMaoObraTemp = s.orcamento.maoDeObra.map(m => ({ ...m, id: orcProximoIdMaoObra++ }));
  } else {
    document.getElementById("orcServico").value = s.servico;
    document.getElementById("orcDescricao").value = "";
    document.getElementById("orcPrazo").value = "";
    document.getElementById("orcObs").value = "";
    orcPecasTemp = [novoItemPeca()];
    orcMaoObraTemp = [novoItemMaoObra()];
  }

  renderOrcPecasEditor();
  renderOrcMaoObraEditor();
  atualizarTotalOrcamento();

  modalOrcamento.classList.add("is-open");
}

function renderOrcPecasEditor(){
  const container = document.getElementById("orcPecasList");
  if (orcPecasTemp.length === 0){
    container.innerHTML = `<p class="items-empty">Nenhuma peça adicionada.</p>`;
    return;
  }
  container.innerHTML = orcPecasTemp.map(p => `
    <div class="item-row" data-peca-id="${p.id}">
      <label>Peça
        <input type="text" class="peca-nome" value="${escapeAttr(p.nome)}" placeholder="Ex: Pastilha de freio dianteira">
      </label>
      <label>Quantidade
        <input type="number" class="peca-qtd" min="1" step="1" value="${p.quantidade}">
      </label>
      <label>Valor unitário (R$)
        <input type="number" class="peca-valor" min="0" step="0.01" value="${p.valorUnitario}">
      </label>
      <label>Total
        <span class="item-total">${formatBRL(p.quantidade * p.valorUnitario)}</span>
      </label>
      <button type="button" class="item-row__remove" data-remove-peca="${p.id}" title="Remover peça">✕</button>
    </div>
  `).join("");

  container.querySelectorAll("[data-remove-peca]").forEach(btn => {
    btn.addEventListener("click", () => {
      orcPecasTemp = orcPecasTemp.filter(p => p.id !== Number(btn.dataset.removePeca));
      renderOrcPecasEditor();
      atualizarTotalOrcamento();
    });
  });
  container.querySelectorAll(".item-row").forEach(row => {
    const id = Number(row.dataset.pecaId);
    row.querySelector(".peca-nome").addEventListener("input", (e) => atualizarItemPeca(id, "nome", e.target.value));
    row.querySelector(".peca-qtd").addEventListener("input", (e) => atualizarItemPeca(id, "quantidade", e.target.value));
    row.querySelector(".peca-valor").addEventListener("input", (e) => atualizarItemPeca(id, "valorUnitario", e.target.value));
  });
}

function atualizarItemPeca(id, campo, valor){
  const item = orcPecasTemp.find(p => p.id === id);
  if (!item) return;
  if (campo === "quantidade") item.quantidade = Math.max(0, parseFloat(valor) || 0);
  else if (campo === "valorUnitario") item.valorUnitario = Math.max(0, parseFloat(valor) || 0);
  else item[campo] = valor;

  const row = document.querySelector(`#orcPecasList [data-peca-id="${id}"] .item-total`);
  if (row) row.textContent = formatBRL(item.quantidade * item.valorUnitario);
  atualizarTotalOrcamento();
}

function renderOrcMaoObraEditor(){
  const container = document.getElementById("orcMaoObraList");
  if (orcMaoObraTemp.length === 0){
    container.innerHTML = `<p class="items-empty">Nenhum serviço de mão de obra adicionado.</p>`;
    return;
  }
  container.innerHTML = orcMaoObraTemp.map(m => `
    <div class="item-row" data-mo-id="${m.id}">
      <label>Serviço
        <input type="text" class="mo-descricao" value="${escapeAttr(m.descricao)}" placeholder="Ex: Troca das pastilhas de freio">
      </label>
      <label>Quantidade
        <input type="number" class="mo-qtd" min="1" step="1" value="${m.quantidade}">
      </label>
      <label>Valor (R$)
        <input type="number" class="mo-valor" min="0" step="0.01" value="${m.valorUnitario}">
      </label>
      <label>Total
        <span class="item-total">${formatBRL(m.quantidade * m.valorUnitario)}</span>
      </label>
      <button type="button" class="item-row__remove" data-remove-mo="${m.id}" title="Remover">✕</button>
    </div>
  `).join("");

  container.querySelectorAll("[data-remove-mo]").forEach(btn => {
    btn.addEventListener("click", () => {
      orcMaoObraTemp = orcMaoObraTemp.filter(m => m.id !== Number(btn.dataset.removeMo));
      renderOrcMaoObraEditor();
      atualizarTotalOrcamento();
    });
  });
  container.querySelectorAll(".item-row").forEach(row => {
    const id = Number(row.dataset.moId);
    row.querySelector(".mo-descricao").addEventListener("input", (e) => atualizarItemMaoObra(id, "descricao", e.target.value));
    row.querySelector(".mo-qtd").addEventListener("input", (e) => atualizarItemMaoObra(id, "quantidade", e.target.value));
    row.querySelector(".mo-valor").addEventListener("input", (e) => atualizarItemMaoObra(id, "valorUnitario", e.target.value));
  });
}

function atualizarItemMaoObra(id, campo, valor){
  const item = orcMaoObraTemp.find(m => m.id === id);
  if (!item) return;
  if (campo === "quantidade") item.quantidade = Math.max(0, parseFloat(valor) || 0);
  else if (campo === "valorUnitario") item.valorUnitario = Math.max(0, parseFloat(valor) || 0);
  else item[campo] = valor;

  const row = document.querySelector(`#orcMaoObraList [data-mo-id="${id}"] .item-total`);
  if (row) row.textContent = formatBRL(item.quantidade * item.valorUnitario);
  atualizarTotalOrcamento();
}

document.getElementById("btnAddPeca").addEventListener("click", () => {
  orcPecasTemp.push(novoItemPeca());
  renderOrcPecasEditor();
  atualizarTotalOrcamento();
});
document.getElementById("btnAddMaoObra").addEventListener("click", () => {
  orcMaoObraTemp.push(novoItemMaoObra());
  renderOrcMaoObraEditor();
  atualizarTotalOrcamento();
});

function atualizarTotalOrcamento(){
  const subtotalPecas = orcPecasTemp.reduce((acc, p) => acc + (p.quantidade * p.valorUnitario), 0);
  const subtotalMaoObra = orcMaoObraTemp.reduce((acc, m) => acc + (m.quantidade * m.valorUnitario), 0);
  const total = subtotalPecas + subtotalMaoObra;

  document.getElementById("orcSubtotalPecas").textContent = formatBRL(subtotalPecas);
  document.getElementById("orcSubtotalMaoObra").textContent = formatBRL(subtotalMaoObra);
  document.getElementById("orcTotal").textContent = formatBRL(total);

  return { subtotalPecas, subtotalMaoObra, total };
}

document.getElementById("formOrcamento").addEventListener("submit", (e) => {
  e.preventDefault();
  const id = Number(document.getElementById("orcSolicitacaoId").value);
  const s = solicitacoes.find(x => x.id === id);
  if (!s) return;

  const { subtotalPecas, subtotalMaoObra, total } = atualizarTotalOrcamento();

  const pecasFinal = orcPecasTemp
    .filter(p => (p.nome || "").trim() !== "")
    .map(p => ({
      id: p.id, nome: p.nome, descricao: p.descricao || "",
      quantidade: p.quantidade, valorUnitario: p.valorUnitario,
      total: p.quantidade * p.valorUnitario,
      aprovado: null // preparado para aprovação individual futura
    }));

  const maoObraFinal = orcMaoObraTemp
    .filter(m => (m.descricao || "").trim() !== "")
    .map(m => ({
      id: m.id, descricao: m.descricao,
      quantidade: m.quantidade, valorUnitario: m.valorUnitario,
      total: m.quantidade * m.valorUnitario,
      aprovado: null
    }));

  const orcamentoAnterior = s.orcamento ? JSON.parse(JSON.stringify(s.orcamento)) : null;
  s.oficinaId = sessao && sessao.tipo === "oficina" ? sessao.cpf : (s.oficinaId || null);
  s.orcamento = {
    servico: document.getElementById("orcServico").value,
    descricao: document.getElementById("orcDescricao").value,
    pecas: pecasFinal,
    maoDeObra: maoObraFinal,
    subtotalPecas: subtotalPecas,
    subtotalMaoDeObra: subtotalMaoObra,
    total: total,
    valorAprovado: null,
    prazo: document.getElementById("orcPrazo").value,
    obs: document.getElementById("orcObs").value
  };

  // Registro de versão para auditoria de alterações da proposta.
  s.historicoOrcamentos = s.historicoOrcamentos || [];
  s.historicoOrcamentos.push({versao:s.historicoOrcamentos.length+1,data:new Date().toISOString(),ator:sessao?.cpf||"oficina",anterior:orcamentoAnterior,novo:JSON.parse(JSON.stringify(s.orcamento))});
  s.historico = s.historico || [];
  s.historico.push({status:"aprovacao",data:new Date().toISOString(),ator:"oficina",descricao:orcamentoAnterior?"Orçamento revisado e reenviado":"Orçamento elaborado e enviado ao cliente"});
  // Envio persistido para a conta do cliente relacionado.
  s.status = "aprovacao";
  criarNotificacao({destinatario:`cliente:${s.clienteId}`,tipo:"cliente",titulo:"Novo orçamento disponível",mensagem:`${s.orcamento.servico} • ${formatBRL(s.orcamento.total)} • Pedido LC-${s.id}`,solicitacaoId:s.id,evento:`orcamento-enviado-${s.id}-${JSON.stringify(s.orcamento).length}`});
  salvarSolicitacoes();

  fecharModais();
  renderAll();
  mostrarToast(`Orçamento de ${s.cliente} enviado ao cliente via LaunchControl.`);
});

// =========================================================
// 9. MODAL: DETALHE DO ORÇAMENTO (oficina — leitura + editar)
// =========================================================
function tabelaItensLeitura(titulo, itens, colunaNome){
  if (!itens || itens.length === 0){
    return `<div class="orc-table-wrap"><h4>${titulo}</h4><p class="items-empty">Nenhum item.</p></div>`;
  }
  return `
    <div class="orc-table-wrap">
      <h4>${titulo}</h4>
      <table class="orc-mini-table">
        <thead><tr><th>${colunaNome}</th><th class="num">Qtd.</th><th class="num">Valor unitário</th><th class="num">Total</th></tr></thead>
        <tbody>
          ${itens.map(it => `
            <tr>
              <td>${colunaNome === "Item" ? it.nome : it.descricao}</td>
              <td class="num">${it.quantidade}</td>
              <td class="num">${formatBRL(it.valorUnitario)}</td>
              <td class="num">${formatBRL(it.total)}</td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    </div>
  `;
}

function abrirDetalheOrcamentoOficina(id){
  const s = solicitacoes.find(x => x.id === id);
  if (!s || !s.orcamento) return;
  const o = s.orcamento;

  document.getElementById("orcamentoDetalheOficinaBody").innerHTML = `
    <div class="detail-grid">
      <div class="detail-item"><div class="k">Cliente</div><div class="v">${s.cliente}</div></div>
      <div class="detail-item"><div class="k">CPF</div><div class="v mono">${mascararCpf(s.clienteId)}</div></div>
      <div class="detail-item"><div class="k">Veículo</div><div class="v">${s.veiculo} · ${s.ano}</div></div>
      <div class="detail-item"><div class="k">Serviço</div><div class="v">${o.servico}</div></div>
      <div class="detail-item"><div class="k">Data</div><div class="v">${s.data}</div></div>
      <div class="detail-item"><div class="k">Prazo</div><div class="v">${o.prazo || "—"}</div></div>
      <div class="detail-item"><div class="k">Status</div><div class="v">${statusBadge(s.status)}</div></div>
      ${o.obs ? `<div class="detail-item full"><div class="k">Observações</div><div class="v" style="font-weight:400;">${o.obs}</div></div>` : ""}
    </div>

    ${tabelaItensLeitura("Peças", o.pecas, "Item")}
    ${tabelaItensLeitura("Mão de obra", o.maoDeObra, "Serviço")}

    <div class="orc-summary">
      <span>Subtotal das peças: <strong class="mono">${formatBRL(o.subtotalPecas)}</strong></span>
      <span>Subtotal da mão de obra: <strong class="mono">${formatBRL(o.subtotalMaoDeObra)}</strong></span>
      <span class="grand">Total: ${formatBRL(o.total)}</span>
    </div>

    ${s.status === "concluido" ? "" : `
    <div class="modal__actions">
      <button type="button" class="btn btn--primary" id="btnEditarOrcamento">Editar orçamento</button>
    </div>`}
  `;

  const btnEditar = document.getElementById("btnEditarOrcamento");
  if (btnEditar){
    btnEditar.addEventListener("click", () => {
      fecharModais();
      abrirOrcamento(s.id);
    });
  }

  modalOrcamentoDetalheOficina.classList.add("is-open");
}

// =========================================================
// 10. FECHAMENTO DE MODAIS
// =========================================================
function fecharModais(){
  [modalDetalhe, modalOrcamento, modalOrcamentoDetalheOficina, modalDetalheCli, modalOrcamentoCliente, modalCartao, modalPagamento, modalFoto]
    .forEach(m => m.classList.remove("is-open"));
}
document.getElementById("closeDetalhe").addEventListener("click", fecharModais);
document.getElementById("closeOrcamento").addEventListener("click", fecharModais);
document.getElementById("cancelOrcamento").addEventListener("click", fecharModais);
document.getElementById("closeOrcamentoDetalheOficina").addEventListener("click", fecharModais);
document.getElementById("closeDetalheCli").addEventListener("click", fecharModais);
document.getElementById("closeOrcamentoCliente").addEventListener("click", fecharModais);
[modalDetalhe, modalOrcamento, modalOrcamentoDetalheOficina, modalDetalheCli, modalOrcamentoCliente, modalCartao, modalPagamento].forEach(overlay => {
  overlay.addEventListener("click", (e) => { if (e.target === overlay) fecharModais(); });
});

// =========================================================
// 11. RENDERIZAÇÃO — PAINEL DO CLIENTE
// =========================================================
function renderCliente(){
  const c = clienteAtual();
  if (!c) return;
  const minhas = solicitacoesDoCliente();

  renderCliKpis(minhas);
  renderRequestListCli(document.getElementById("cliRecentRequests"), minhas.slice(0, 3));
  renderRequestListCli(document.getElementById("cliAllRequests"), minhas);
  renderCliVeiculos(c);
  renderCliOrcamentosTable(minhas);
  renderCliServicosTable(minhas);
  renderCliPagamentos(minhas, c);
  renderCliPerfil(c);
}

function renderCliKpis(minhas){
  const ultima = minhas[0];
  const pendente = minhas.find(s => s.status === "aprovacao" || s.status === "aprovado_parcial");
  const andamento = minhas.find(s => s.status === "execucao" || s.status === "aprovado");
  const concluidos = minhas.filter(s => s.status === "concluido").length;

  const cards = [
    { label: "Última solicitação", value: ultima ? ultima.servico : "—", icon: "▤", color: "var(--accent)" },
    { label: "Orçamento pendente", value: pendente ? formatBRL(pendente.orcamento.total) : "Nenhum", icon: "🧾", color: "var(--amber)" },
    { label: "Serviço em andamento", value: andamento ? andamento.servico : "Nenhum", icon: "🔧", color: "var(--purple)" },
    { label: "Serviços concluídos", value: concluidos, icon: "✅", color: "var(--teal)" }
  ];

  document.getElementById("cliKpiCards").innerHTML = cards.map(c => `
    <div class="kpi-card" style="--kpi-color:${c.color}">
      <span class="kpi-icon">${c.icon}</span>
      <div class="kpi-label">${c.label}</div>
      <div class="kpi-value" style="font-size:16px; font-family:var(--font-body);">${c.value}</div>
    </div>
  `).join("");
}

function renderRequestListCli(container, list){
  if (!container) return;
  if (list.length === 0){
    container.innerHTML = `<p style="color:var(--ink-soft); padding:20px 0;">Nenhuma solicitação por aqui.</p>`;
    return;
  }
  container.innerHTML = list.map(s => `
    <div class="req-card">
      <div class="req-card__main">
        <div class="req-field"><span class="k">Veículo</span><span class="v">${s.veiculo} · ${s.ano}</span></div>
        <div class="req-field"><span class="k">Serviço</span><span class="v">${s.servico}</span></div>
        <div class="req-field"><span class="k">Data</span><span class="v mono">${s.data}</span></div>
        <div class="req-field"><span class="k">&nbsp;</span><span class="v">&nbsp;</span></div>
      </div>
      <div>${statusBadge(s.status)}</div>
      <button class="btn btn--outline" data-detalhe-cli="${s.id}">Visualizar</button>
    </div>
  `).join("");

  container.querySelectorAll("[data-detalhe-cli]").forEach(btn => {
    btn.addEventListener("click", () => abrirDetalheCliente(Number(btn.dataset.detalheCli)));
  });
}

function renderCliVeiculos(c){
  const container = document.getElementById("cliVeiculosCards");
  if (!container) return;
  container.innerHTML = c.veiculos.map(v => `
    <div class="veiculo-card">
      <strong>${v.modelo}</strong>
      <p>Ano ${v.ano} · Placa ${v.placa}</p>
      <p>${v.km}</p>
    </div>
  `).join("");
}

function renderCliOrcamentosTable(minhas){
  const tbody = document.querySelector("#cliOrcamentosTable tbody");
  if (!tbody) return;
  const comOrcamento = minhas.filter(s => s.orcamento);
  if (comOrcamento.length === 0){
    tbody.innerHTML = `<tr><td colspan="4" style="color:var(--ink-soft); padding:24px 0;">Você ainda não recebeu nenhum orçamento.</td></tr>`;
    return;
  }
  tbody.innerHTML = comOrcamento.map(s => `
    <tr class="row-click" data-orc-cli="${s.id}">
      <td>${s.veiculo}</td>
      <td>${s.orcamento.servico}</td>
      <td class="mono">${formatBRL(s.orcamento.total)}</td>
      <td>${statusBadge(s.status)}</td>
    </tr>
  `).join("");

  tbody.querySelectorAll("[data-orc-cli]").forEach(tr => {
    tr.addEventListener("click", () => abrirOrcamentoCliente(Number(tr.dataset.orcCli)));
  });
}

function renderCliServicosTable(minhas){
  const tbody = document.querySelector("#cliServicosTable tbody");
  if (!tbody) return;
  const emServico = minhas.filter(s => ["aprovado", "execucao", "concluido"].includes(s.status));
  if (emServico.length === 0){
    tbody.innerHTML = `<tr><td colspan="5" style="color:var(--ink-soft); padding:24px 0;">Nenhum serviço em andamento ou concluído.</td></tr>`;
    return;
  }
  tbody.innerHTML = emServico.map(s => `
    <tr>
      <td>${s.veiculo}</td>
      <td>${s.servico}</td>
      <td class="mono">${s.entrada || "—"}</td>
      <td class="mono">${s.previsao || "—"}</td>
      <td>${statusBadge(s.status)}</td>
    </tr>
  `).join("");
}

function renderCliPerfil(c){
  const container = document.getElementById("cliPerfilInfo");
  if (!container) return;
  container.innerHTML = `
    <div class="detail-item"><div class="k">Nome</div><div class="v">${c.nome}</div></div>
    <div class="detail-item"><div class="k">CPF</div><div class="v mono">${mascararCpf(c.cpf)}</div></div>
    <div class="detail-item"><div class="k">Telefone</div><div class="v">${c.telefone}</div></div>
    <div class="detail-item"><div class="k">E-mail</div><div class="v">${c.email}</div></div>
    <div class="detail-item full"><div class="k">Veículos</div><div class="v" style="font-weight:400;">${c.veiculos.map(v => `${v.modelo} (${v.ano})`).join(", ")}</div></div>
  `;
}

// ---- Modal: detalhe da solicitação (cliente, somente leitura) ----
function abrirDetalheCliente(id){
  const s = solicitacoes.find(x => x.id === id && x.clienteId === sessao.cpf);
  if (!s) return;

  document.getElementById("detalheCliBody").innerHTML = `
    <div class="detail-grid">
      <div class="detail-item"><div class="k">Veículo</div><div class="v">${s.veiculo}</div></div>
      <div class="detail-item"><div class="k">Ano</div><div class="v">${s.ano}</div></div>
      <div class="detail-item"><div class="k">Quilometragem</div><div class="v">${s.km}</div></div>
      <div class="detail-item"><div class="k">Data da solicitação</div><div class="v">${s.data}</div></div>
      <div class="detail-item full"><div class="k">Serviço solicitado</div><div class="v">${s.servico}</div></div>
      <div class="detail-item full"><div class="k">Descrição do problema</div><div class="v" style="font-weight:400;">${s.descricao}</div></div>
      <div class="detail-item full">
        <div class="k">Fotos do veículo / problema</div>
        <div class="photo-zone">${fotosBlocoHtml(s, s.status !== "concluido")}</div>
      </div>
      <div class="detail-item"><div class="k">Status atual</div><div class="v">${statusBadge(s.status)}</div></div>
    </div>
    ${s.orcamento ? `
      <div class="modal__actions">
        <button type="button" class="btn btn--primary" id="btnVerOrcamentoCli">Ver orçamento detalhado</button>
      </div>
    ` : ""}
  `;

  const btnVer = document.getElementById("btnVerOrcamentoCli");
  if (btnVer){
    btnVer.addEventListener("click", () => {
      fecharModais();
      abrirOrcamentoCliente(s.id);
    });
  }

  ligarFotos(document.getElementById("detalheCliBody"), s, s.status !== "concluido",
    () => { abrirDetalheCliente(s.id); renderCliente(); });
  modalDetalheCli.classList.add("is-open");
}

// ---- Modal: orçamento detalhado do cliente (aprovar/recusar) ----
function abrirOrcamentoCliente(id){
  const s = solicitacoes.find(x => x.id === id && x.clienteId === sessao.cpf);
  if (!s || !s.orcamento) return;
  const o = s.orcamento;

  const decisaoJaTomada = ["aprovado", "aprovado_parcial", "recusado_cliente"].includes(s.status);

  const linhaItem = (it, tipo) => `
    <tr>
      <td class="chk-col">
        <input type="checkbox" class="item-aprova" data-tipo="${tipo}" data-id="${it.id}"
          ${(it.aprovado === false ? "" : "checked")} ${decisaoJaTomada ? "disabled" : ""}>
      </td>
      <td>${tipo === "peca" ? it.nome : it.descricao}</td>
      <td class="num">${it.quantidade}</td>
      <td class="num">${formatBRL(it.valorUnitario)}</td>
      <td class="num">${formatBRL(it.total)}</td>
    </tr>
  `;

  document.getElementById("orcamentoClienteBody").innerHTML = `
    <div class="detail-grid">
      <div class="detail-item"><div class="k">Veículo</div><div class="v">${s.veiculo}</div></div>
      <div class="detail-item"><div class="k">Serviço</div><div class="v">${o.servico}</div></div>
      <div class="detail-item"><div class="k">Prazo estimado</div><div class="v">${o.prazo || "—"}</div></div>
      <div class="detail-item"><div class="k">Status</div><div class="v">${statusBadge(s.status)}</div></div>
      ${o.obs ? `<div class="detail-item full"><div class="k">Observações da oficina</div><div class="v" style="font-weight:400;">${o.obs}</div></div>` : ""}
    </div>

    <div class="orc-table-wrap">
      <h4>Peças</h4>
      <table class="orc-mini-table">
        <thead><tr><th class="chk-col"></th><th>Item</th><th class="num">Qtd.</th><th class="num">Valor unitário</th><th class="num">Total</th></tr></thead>
        <tbody>${o.pecas.map(p => linhaItem(p, "peca")).join("")}</tbody>
      </table>
    </div>

    <div class="orc-table-wrap">
      <h4>Mão de obra</h4>
      <table class="orc-mini-table">
        <thead><tr><th class="chk-col"></th><th>Serviço</th><th class="num">Qtd.</th><th class="num">Valor unitário</th><th class="num">Total</th></tr></thead>
        <tbody>${o.maoDeObra.map(m => linhaItem(m, "mo")).join("")}</tbody>
      </table>
    </div>

    <div class="orc-summary">
      <span>Total do orçamento: <strong class="mono">${formatBRL(o.total)}</strong></span>
      <span class="grand" id="orcClienteValorSelecionado">Selecionado: ${formatBRL(o.valorAprovado != null ? o.valorAprovado : o.total)}</span>
    </div>

    ${decisaoJaTomada ? `
      <p style="color:var(--ink-soft); font-size:13px;">Você já respondeu a este orçamento. O status atual é exibido acima.</p>
    ` : `
      <div class="modal__actions" style="justify-content:space-between; flex-wrap:wrap; gap:10px;">
        <button type="button" class="btn btn--outline" id="btnSalvarSelecao">Aprovar itens selecionados</button>
        <div style="display:flex; gap:10px;">
          <button type="button" class="btn btn--danger" id="btnRecusarTudo">Recusar orçamento completo</button>
          <button type="button" class="btn btn--primary" id="btnAprovarTudo">Aprovar orçamento completo</button>
        </div>
      </div>
    `}
  `;

  if (!decisaoJaTomada){
    const checkboxes = () => Array.from(document.querySelectorAll("#orcamentoClienteBody .item-aprova"));

    function recalcularSelecionado(){
      let soma = 0;
      checkboxes().forEach(cb => {
        if (!cb.checked) return;
        const lista = cb.dataset.tipo === "peca" ? o.pecas : o.maoDeObra;
        const item = lista.find(it => it.id === Number(cb.dataset.id));
        if (item) soma += item.total;
      });
      document.getElementById("orcClienteValorSelecionado").textContent = `Selecionado: ${formatBRL(soma)}`;
      return soma;
    }

    checkboxes().forEach(cb => cb.addEventListener("change", recalcularSelecionado));

    function aplicarDecisao(modoForcado){
      // modoForcado: true = aprovar tudo, false = recusar tudo, null = usa checkboxes
      let totalAprovados = 0;
      let totalItens = o.pecas.length + o.maoDeObra.length;
      let contAprovados = 0;

      o.pecas.forEach(p => {
        const cb = document.querySelector(`.item-aprova[data-tipo="peca"][data-id="${p.id}"]`);
        const aprovado = modoForcado === null ? (cb ? cb.checked : true) : modoForcado;
        p.aprovado = aprovado;
        if (aprovado) { totalAprovados += p.total; contAprovados++; }
      });
      o.maoDeObra.forEach(m => {
        const cb = document.querySelector(`.item-aprova[data-tipo="mo"][data-id="${m.id}"]`);
        const aprovado = modoForcado === null ? (cb ? cb.checked : true) : modoForcado;
        m.aprovado = aprovado;
        if (aprovado) { totalAprovados += m.total; contAprovados++; }
      });

      o.valorAprovado = totalAprovados;

      if (contAprovados === totalItens) s.status = "aprovado";
      else if (contAprovados === 0) s.status = "recusado_cliente";
      else s.status = "aprovado_parcial";

      const statusOrc = s.status === "aprovado" ? "aprovado" : s.status === "recusado_cliente" ? "recusado" : "aprovado parcialmente";
      const oficinaDestino = s.oficinaId || oficinas[0]?.cpf;
      if (oficinaDestino) criarNotificacao({destinatario:`oficina:${oficinaDestino}`,tipo:"oficina",titulo:"Resposta do cliente ao orçamento",mensagem:`${s.cliente} ${statusOrc} o orçamento de ${o.servico} • ${formatBRL(o.valorAprovado)} • Pedido LC-${s.id}`,solicitacaoId:s.id,evento:`orcamento-resposta-${s.id}`});
      registrarHistorico(s,s.status,"cliente",`Cliente ${statusOrc} a proposta (${formatBRL(o.valorAprovado)})`);
      salvarSolicitacoes();
      fecharModais();
      renderCliente();
      renderAll(); // mantém o painel da oficina sincronizado quando o usuário voltar a ele
      mostrarToast(s.status === "aprovado"
        ? "Orçamento aprovado! A oficina foi notificada."
        : s.status === "recusado_cliente"
          ? "Orçamento recusado."
          : "Aprovação parcial registrada. A oficina foi notificada.");
    }

    document.getElementById("btnAprovarTudo").addEventListener("click", () => aplicarDecisao(true));
    document.getElementById("btnRecusarTudo").addEventListener("click", () => aplicarDecisao(false));
    document.getElementById("btnSalvarSelecao").addEventListener("click", () => aplicarDecisao(null));
  }

  modalOrcamentoCliente.classList.add("is-open");
}

// =========================================================
// 12. FOTOS DO VEÍCULO — miniaturas clicáveis, lightbox e anexo (cliente)
//     As fotos são reduzidas no navegador (máx. 900px, JPEG) e guardadas
//     em s.fotosData. Futuro: enviar o arquivo original para storage (S3 etc.)
//     e guardar só a URL.
// =========================================================
const MAX_FOTOS = 6;

function normalizarFotos(s){
  s.fotos = s.fotos || 0;
  s.fotosData = Array.from({ length: s.fotos }, (_, i) => (s.fotosData && s.fotosData[i]) || null);
}

function fotosBlocoHtml(s, editavel){
  normalizarFotos(s);
  if (!editavel && s.fotos === 0){
    return `<p class="photo-empty">Nenhuma foto enviada.</p>`;
  }
  const thumbs = s.fotosData.map((url, i) => `
    <div class="photo-item">
      <button type="button" class="photo-thumb" data-foto-abrir="${i}" aria-label="Ampliar foto ${i + 1}">
        ${url ? `<img src="${url}" alt="Foto ${i + 1} do veículo">` : `<span>📷</span>`}
      </button>
      ${editavel ? `<button type="button" class="photo-del" data-foto-remover="${i}" aria-label="Remover foto ${i + 1}">✕</button>` : ""}
    </div>
  `).join("");
  const add = editavel && s.fotos < MAX_FOTOS ? `
    <label class="photo-add">
      <input type="file" accept="image/*" multiple hidden data-foto-input>
      <span class="photo-add__plus">＋</span>
      <small>Adicionar</small>
    </label>` : "";
  return `
    <div class="photo-row">${thumbs}${add}</div>
    ${editavel ? `<p class="photo-hint">Clique para ampliar · arraste imagens para cá ou use “Adicionar” (até ${MAX_FOTOS} fotos).</p>` : ""}
  `;
}

function reduzirImagem(file, max = 900){
  return new Promise((ok, falha) => {
    const fr = new FileReader();
    fr.onerror = falha;
    fr.onload = () => {
      const img = new Image();
      img.onerror = falha;
      img.onload = () => {
        const r = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement("canvas");
        c.width = Math.round(img.width * r);
        c.height = Math.round(img.height * r);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        ok(c.toDataURL("image/jpeg", 0.72));
      };
      img.src = fr.result;
    };
    fr.readAsDataURL(file);
  });
}

async function anexarFotos(s, arquivos, aoMudar){
  normalizarFotos(s);
  const imagens = Array.from(arquivos).filter(f => f.type.startsWith("image/"));
  if (imagens.length === 0){ mostrarToast("Selecione arquivos de imagem."); return; }
  const vagas = MAX_FOTOS - s.fotos;
  if (vagas <= 0){ mostrarToast(`Limite de ${MAX_FOTOS} fotos atingido.`); return; }
  const lote = imagens.slice(0, vagas);
  const antesData = s.fotosData.slice(), antesQtd = s.fotos;
  try {
    for (const f of lote){
      s.fotosData.push(await reduzirImagem(f));
      s.fotos = s.fotosData.length;
    }
    salvarSolicitacoes();
  } catch (err){
    s.fotosData = antesData; s.fotos = antesQtd; // desfaz se não coube no armazenamento local
    mostrarToast("Não foi possível anexar (imagem inválida ou sem espaço no navegador).");
    return;
  }
  mostrarToast(lote.length === 1 ? "Foto anexada." : `${lote.length} fotos anexadas.`);
  if (imagens.length > vagas) mostrarToast(`Só cabem ${MAX_FOTOS} fotos: as demais foram ignoradas.`);
  aoMudar();
}

function ligarFotos(container, s, editavel, aoMudar){
  const zona = container.querySelector(".photo-zone");
  if (!zona) return;
  zona.querySelectorAll("[data-foto-abrir]").forEach(b =>
    b.addEventListener("click", () => abrirFoto(s.id, Number(b.dataset.fotoAbrir))));
  if (!editavel) return;
  zona.querySelectorAll("[data-foto-remover]").forEach(b =>
    b.addEventListener("click", () => {
      const i = Number(b.dataset.fotoRemover);
      s.fotosData.splice(i, 1);
      s.fotos = s.fotosData.length;
      salvarSolicitacoes();
      aoMudar();
    }));
  const input = zona.querySelector("[data-foto-input]");
  if (input) input.addEventListener("change", () => anexarFotos(s, input.files, aoMudar));
  zona.addEventListener("dragover", (e) => { e.preventDefault(); zona.classList.add("is-drag"); });
  zona.addEventListener("dragleave", () => zona.classList.remove("is-drag"));
  zona.addEventListener("drop", (e) => {
    e.preventDefault();
    zona.classList.remove("is-drag");
    if (e.dataTransfer && e.dataTransfer.files.length) anexarFotos(s, e.dataTransfer.files, aoMudar);
  });
}

// ---- lightbox ----
let fotoCtx = null; // { id, i }
function abrirFoto(id, i){
  fotoCtx = { id, i };
  renderFoto();
  modalFoto.classList.add("is-open");
}
function renderFoto(){
  const s = solicitacoes.find(x => x.id === fotoCtx.id);
  if (!s){ modalFoto.classList.remove("is-open"); return; }
  normalizarFotos(s);
  const n = s.fotos;
  fotoCtx.i = (fotoCtx.i + n) % n;
  const url = s.fotosData[fotoCtx.i];
  document.getElementById("fotoStage").innerHTML = url
    ? `<img src="${url}" alt="Foto ${fotoCtx.i + 1} de ${n}">`
    : `<div class="lightbox__placeholder"><span>📷</span><p>Foto de demonstração — nenhuma imagem real foi anexada a este item.</p></div>`;
  document.getElementById("fotoCount").textContent = `${s.veiculo} · foto ${fotoCtx.i + 1} de ${n}`;
  document.getElementById("fotoPrev").style.visibility = n > 1 ? "visible" : "hidden";
  document.getElementById("fotoNext").style.visibility = n > 1 ? "visible" : "hidden";
}
function navegarFoto(d){ if (fotoCtx){ fotoCtx.i += d; renderFoto(); } }
document.getElementById("fotoPrev").addEventListener("click", () => navegarFoto(-1));
document.getElementById("fotoNext").addEventListener("click", () => navegarFoto(1));
document.getElementById("closeFoto").addEventListener("click", () => modalFoto.classList.remove("is-open"));
modalFoto.addEventListener("click", (e) => { if (e.target === modalFoto) modalFoto.classList.remove("is-open"); });
document.addEventListener("keydown", (e) => {
  if (!modalFoto.classList.contains("is-open")) return;
  if (e.key === "Escape") modalFoto.classList.remove("is-open");
  else if (e.key === "ArrowLeft") navegarFoto(-1);
  else if (e.key === "ArrowRight") navegarFoto(1);
});

// =========================================================
// 12c. CONFIGURAÇÕES (oficina)
//      Tudo salvo no localStorage (chave lc_config + dados da conta).
//      Futuro: GET/PUT /configuracoes e PUT /usuarios/me no backend.
// =========================================================
const CONFIG_PADRAO = {
  oficina: { nome: "LaunchControl Oficina", telefone: "", email: "", endereco: "" },
  pagamentos: { cartao: true, pix: true, parcelasMax: 6 }
};
let config = JSON.parse(JSON.stringify(CONFIG_PADRAO));

function carregarConfig(){
  const salvo = lerLS(LS_KEYS.CONFIG, null) || {};
  config = {
    oficina: Object.assign({}, CONFIG_PADRAO.oficina, salvo.oficina),
    pagamentos: Object.assign({}, CONFIG_PADRAO.pagamentos, salvo.pagamentos)
  };
}
function salvarConfig(){
  localStorage.setItem(LS_KEYS.CONFIG, JSON.stringify(config));
}
function oficinaLogada(){
  return sessao && sessao.tipo === "oficina" ? oficinas.find(o => o.cpf === sessao.cpf) : null;
}

function renderConfig(){
  const u = oficinaLogada();
  if (!u) return;
  const set = (id, v) => { document.getElementById(id).value = v; };
  set("cfgNome", u.nome);
  set("cfgCargo", u.cargo || "");
  set("cfgCpf", mascararCpf(u.cpf));
  ["cfgSenhaAtual", "cfgSenhaNova", "cfgSenhaConfirmar"].forEach(id => set(id, ""));
  set("cfgOfNome", config.oficina.nome);
  set("cfgOfTelefone", config.oficina.telefone);
  set("cfgOfEmail", config.oficina.email);
  set("cfgOfEndereco", config.oficina.endereco);
  document.getElementById("cfgPagCartao").checked = config.pagamentos.cartao;
  document.getElementById("cfgPagPix").checked = config.pagamentos.pix;
  set("cfgParcelas", String(config.pagamentos.parcelasMax));
  document.getElementById("cfgParcelas").disabled = !config.pagamentos.cartao;
  document.querySelectorAll("#view-config .field-error").forEach(e => e.textContent = "");
}

function erroCfg(id, msg){ document.getElementById(id).textContent = msg || ""; }

// -- minha conta
document.getElementById("formConfigConta").addEventListener("submit", (e) => {
  e.preventDefault();
  const u = oficinaLogada();
  if (!u) return;
  const nome = document.getElementById("cfgNome").value.trim();
  const cargo = document.getElementById("cfgCargo").value.trim() || "Atendente";
  erroCfg("erroCfgNome", nome.length < 3 || !nome.includes(" ") ? "Informe nome e sobrenome." : "");
  if (document.getElementById("erroCfgNome").textContent) return;
  u.nome = nome; u.cargo = cargo;
  if (sessao.nome !== undefined) sessao.nome = nome;
  salvarOficinas(); salvarSessao();
  document.getElementById("oficinaNome").textContent = nome;
  document.getElementById("oficinaCargo").textContent = cargo;
  document.getElementById("oficinaAvatar").textContent = iniciais(nome);
  mostrarToast("Dados da conta atualizados.");
});

// -- alterar senha
document.getElementById("formConfigSenha").addEventListener("submit", (e) => {
  e.preventDefault();
  const u = oficinaLogada();
  if (!u) return;
  const atual = document.getElementById("cfgSenhaAtual").value;
  const nova = document.getElementById("cfgSenhaNova").value;
  const conf = document.getElementById("cfgSenhaConfirmar").value;
  erroCfg("erroCfgSenhaAtual", atual !== u.senha ? "Senha atual incorreta." : "");
  erroCfg("erroCfgSenhaNova", nova.length < 6 ? "A senha deve ter no mínimo 6 caracteres." : (nova === atual ? "A nova senha deve ser diferente da atual." : ""));
  erroCfg("erroCfgSenhaConfirmar", conf !== nova ? "As senhas não coincidem." : "");
  if (["erroCfgSenhaAtual","erroCfgSenhaNova","erroCfgSenhaConfirmar"].some(id => document.getElementById(id).textContent)) return;
  u.senha = nova; // protótipo: senha em texto puro. Backend real: hash (bcrypt/argon2).
  salvarOficinas();
  ["cfgSenhaAtual", "cfgSenhaNova", "cfgSenhaConfirmar"].forEach(id => document.getElementById(id).value = "");
  mostrarToast("Senha alterada com sucesso.");
});

// -- dados da oficina (aparecem no comprovante de pagamento)
document.getElementById("cfgOfTelefone").addEventListener("input", (e) => {
  e.target.value = mascararTelefone(e.target.value);
});
document.getElementById("formConfigOficina").addEventListener("submit", (e) => {
  e.preventDefault();
  const nome = document.getElementById("cfgOfNome").value.trim();
  const telefone = document.getElementById("cfgOfTelefone").value.trim();
  const email = document.getElementById("cfgOfEmail").value.trim();
  const endereco = document.getElementById("cfgOfEndereco").value.trim();
  erroCfg("erroCfgOfNome", nome.length < 2 ? "Informe o nome da oficina." : "");
  erroCfg("erroCfgOfTelefone", telefone && apenasDigitos(telefone).length < 10 ? "Telefone incompleto." : "");
  erroCfg("erroCfgOfEmail", email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? "E-mail inválido." : "");
  if (["erroCfgOfNome","erroCfgOfTelefone","erroCfgOfEmail"].some(id => document.getElementById(id).textContent)) return;
  config.oficina = { nome, telefone, email, endereco };
  salvarConfig();
  mostrarToast("Dados da oficina salvos.");
});

// -- pagamentos aceitos
document.getElementById("cfgPagCartao").addEventListener("change", (e) => {
  document.getElementById("cfgParcelas").disabled = !e.target.checked;
});
document.getElementById("formConfigPagamentos").addEventListener("submit", (e) => {
  e.preventDefault();
  const cartao = document.getElementById("cfgPagCartao").checked;
  const pix = document.getElementById("cfgPagPix").checked;
  erroCfg("erroCfgPag", !cartao && !pix ? "Mantenha ao menos uma forma de pagamento ativa." : "");
  if (!cartao && !pix) return;
  config.pagamentos = { cartao, pix, parcelasMax: Number(document.getElementById("cfgParcelas").value) };
  salvarConfig();
  mostrarToast("Regras de pagamento salvas.");
});

// -- restaurar dados de demonstração
document.getElementById("btnResetDemo").addEventListener("click", () => {
  const ok = window.confirm("Restaurar os dados de demonstração?\n\nIsso apaga contas criadas, fotos, cartões, pagamentos e configurações deste navegador, e você será desconectado.");
  if (!ok) return;
  Object.values(LS_KEYS).forEach(k => localStorage.removeItem(k));
  window.location.reload();
});

function maxParcelas(){ return config.pagamentos.parcelasMax; }

// =========================================================
// 12b. PAGAMENTOS (cliente) — cartões salvos + PIX
//     Tudo simulado: não existe gateway nem banco por trás.
//     Pontos de integração futura:
//       - cadastrarCartao()   -> tokenizar no gateway (nunca guardar número/CVV)
//       - confirmarPagamento() -> POST /pagamentos (cartão) ou webhook do PIX
//       - gerarPixCopiaECola() -> cobrança PIX real (PSP) em vez de payload local
// =========================================================
const PIX_CHAVE_SIMULADA = "teste@launchcontrol.invalid"; // domínio .invalid: nunca resolve, ninguém recebe de verdade
const STATUS_COM_COBRANCA = ["aprovado", "aprovado_parcial", "execucao", "concluido"];

// ---- cobrança de uma solicitação ----
function valorCobranca(s){
  if (!s || !s.orcamento || !STATUS_COM_COBRANCA.includes(s.status)) return 0;
  return s.orcamento.valorAprovado || 0;
}
function estaPago(s){ return !!(s && s.pagamento && s.pagamento.status === "pago"); }
function pagamentoBadge(s){
  return estaPago(s)
    ? `<span class="status status--concluido">Pago</span>`
    : `<span class="status status--aprovacao">Pendente</span>`;
}
function rotuloMetodo(p){
  if (!p) return "—";
  if (p.metodo === "pix") return "PIX";
  const c = p.cartao || {};
  const tipo = c.tipo === "debito" ? "Débito" : "Crédito";
  const parc = c.tipo !== "debito" && p.parcelas > 1 ? ` · ${p.parcelas}x` : "";
  return `${tipo} ${c.bandeira || ""} •••• ${c.final || ""}${parc}`;
}

// ---- cartões: detecção de bandeira, máscara e validação ----
function detectarBandeira(num){
  const n = apenasDigitos(num);
  if (/^(401178|401179|438935|457631|457632|431274|451416|457393|504175|506699|5067|509|627780|636297|636368|650|6516|6550)/.test(n)) return "Elo";
  if (/^(606282|3841)/.test(n)) return "Hipercard";
  if (/^3[47]/.test(n)) return "Amex";
  if (/^(5[1-5]|222[1-9]|22[3-9]\d|2[3-6]\d\d|27[01]\d|2720)/.test(n)) return "Mastercard";
  if (/^4/.test(n)) return "Visa";
  return "";
}
function mascararNumeroCartao(valor){
  const d = apenasDigitos(valor).slice(0, 19);
  if (detectarBandeira(d) === "Amex"){
    return [d.slice(0,4), d.slice(4,10), d.slice(10,15)].filter(Boolean).join(" ");
  }
  return d.replace(/(\d{4})(?=\d)/g, "$1 ");
}
function mascararValidade(valor){
  const d = apenasDigitos(valor).slice(0, 4);
  return d.length > 2 ? `${d.slice(0,2)}/${d.slice(2)}` : d;
}
function luhnValido(digitos){
  let soma = 0, dobrar = false;
  for (let i = digitos.length - 1; i >= 0; i--){
    let n = Number(digitos[i]);
    if (dobrar){ n *= 2; if (n > 9) n -= 9; }
    soma += n;
    dobrar = !dobrar;
  }
  return digitos.length > 0 && soma % 10 === 0;
}
function validadeOk(mmaa){
  const m = /^(\d{2})\/(\d{2})$/.exec(mmaa);
  if (!m) return false;
  const mes = Number(m[1]), ano = 2000 + Number(m[2]);
  if (mes < 1 || mes > 12) return false;
  const hoje = new Date();
  // vale até o último dia do mês de validade
  return ano > hoje.getFullYear() || (ano === hoje.getFullYear() && mes >= hoje.getMonth() + 1);
}
function cartoesDoCliente(){
  const c = clienteAtual();
  return c ? (c.cartoes || []) : [];
}

// ---- tela "Pagamentos" ----
function renderCliPagamentos(minhas, c){
  const tbody = document.querySelector("#cliPagamentosTable tbody");
  if (tbody){
    const cobrancas = minhas.filter(s => valorCobranca(s) > 0);
    if (cobrancas.length === 0){
      tbody.innerHTML = `<tr><td colspan="5" style="color:var(--ink-soft); padding:24px 0;">Nenhuma cobrança por enquanto. Os valores aparecem aqui depois que você aprova um orçamento.</td></tr>`;
    } else {
      tbody.innerHTML = cobrancas.map(s => `
        <tr>
          <td>${s.veiculo}</td>
          <td>${s.orcamento.servico}</td>
          <td class="mono">${formatBRL(valorCobranca(s))}</td>
          <td>${pagamentoBadge(s)}${estaPago(s) ? `<div class="pay-meta">${rotuloMetodo(s.pagamento)}</div>` : ""}</td>
          <td class="td-action">
            <button type="button" class="btn ${estaPago(s) ? "btn--outline" : "btn--primary"} btn--small" data-pagar="${s.id}">
              ${estaPago(s) ? "Comprovante" : "Pagar"}
            </button>
          </td>
        </tr>
      `).join("");
      tbody.querySelectorAll("[data-pagar]").forEach(btn => {
        btn.addEventListener("click", () => abrirPagamento(Number(btn.dataset.pagar)));
      });
    }
  }

  const lista = document.getElementById("cliCartoesList");
  if (lista){
    const cartoes = c.cartoes || [];
    if (cartoes.length === 0){
      lista.innerHTML = `<p class="items-empty">Você ainda não salvou nenhum cartão.</p>`;
      return;
    }
    lista.innerHTML = cartoes.map(k => `
      <div class="saved-card" data-brand="${k.bandeira}">
        <div class="saved-card__top">
          <strong>${k.bandeira || "Cartão"}</strong>
          <span class="saved-card__tipo">${k.tipo === "debito" ? "Débito" : "Crédito"}</span>
        </div>
        <div class="saved-card__num">•••• •••• •••• ${k.final}</div>
        <div class="saved-card__bottom">
          <span>${escapeAttr(k.titular)}</span>
          <span class="mono">${k.validade}</span>
        </div>
        <div class="saved-card__actions">
          ${k.padrao ? `<span class="saved-card__padrao">Padrão</span>` : `<button type="button" class="btn-text" data-cartao-padrao="${k.id}">Tornar padrão</button>`}
          <button type="button" class="btn-text btn-text--danger" data-cartao-remover="${k.id}">Remover</button>
        </div>
      </div>
    `).join("");
    lista.querySelectorAll("[data-cartao-padrao]").forEach(b =>
      b.addEventListener("click", () => definirCartaoPadrao(b.dataset.cartaoPadrao)));
    lista.querySelectorAll("[data-cartao-remover]").forEach(b =>
      b.addEventListener("click", () => removerCartao(b.dataset.cartaoRemover)));
  }
}

function definirCartaoPadrao(id){
  const c = clienteAtual();
  if (!c) return;
  (c.cartoes || []).forEach(k => k.padrao = (k.id === id));
  salvarClientes();
  renderCliente();
  mostrarToast("Cartão padrão atualizado.");
}
function removerCartao(id){
  const c = clienteAtual();
  if (!c) return;
  const eraPadrao = (c.cartoes || []).find(k => k.id === id)?.padrao;
  c.cartoes = (c.cartoes || []).filter(k => k.id !== id);
  if (eraPadrao && c.cartoes.length) c.cartoes[0].padrao = true;
  salvarClientes();
  renderCliente();
  mostrarToast("Cartão removido.");
}

// ---- modal: cadastrar cartão ----
let aoSalvarCartao = null; // callback opcional (ex.: voltar ao pagamento)

function abrirModalCartao(callback){
  aoSalvarCartao = typeof callback === "function" ? callback : null;
  document.getElementById("formCartao").reset();
  ["erroCartaoNumero","erroCartaoTitular","erroCartaoValidade","erroCartaoCvv"]
    .forEach(id => document.getElementById(id).textContent = "");
  atualizarPreviewCartao();
  modalCartao.classList.add("is-open");
  setTimeout(() => document.getElementById("cartaoNumero").focus(), 50);
}

function atualizarPreviewCartao(){
  const num = document.getElementById("cartaoNumero").value;
  const bandeira = detectarBandeira(num);
  const prev = document.getElementById("cartaoPreview");
  prev.dataset.brand = bandeira;
  document.getElementById("prevBandeira").textContent = bandeira || "Cartão";
  document.getElementById("prevNumero").textContent = num.trim() || "•••• •••• •••• ••••";
  document.getElementById("prevTitular").textContent =
    (document.getElementById("cartaoTitular").value.trim() || "NOME DO TITULAR").toUpperCase();
  document.getElementById("prevValidade").textContent =
    document.getElementById("cartaoValidade").value || "MM/AA";
}

document.getElementById("cartaoNumero").addEventListener("input", (e) => {
  e.target.value = mascararNumeroCartao(e.target.value);
  atualizarPreviewCartao();
});
document.getElementById("cartaoTitular").addEventListener("input", atualizarPreviewCartao);
document.getElementById("cartaoValidade").addEventListener("input", (e) => {
  e.target.value = mascararValidade(e.target.value);
  atualizarPreviewCartao();
});
document.getElementById("cartaoCvv").addEventListener("input", (e) => {
  e.target.value = apenasDigitos(e.target.value).slice(0, 4);
});
document.getElementById("btnNovoCartao").addEventListener("click", () => abrirModalCartao());

document.getElementById("formCartao").addEventListener("submit", (e) => {
  e.preventDefault();
  const c = clienteAtual();
  if (!c) return;

  const numero = apenasDigitos(document.getElementById("cartaoNumero").value);
  const titular = document.getElementById("cartaoTitular").value.trim();
  const validade = document.getElementById("cartaoValidade").value.trim();
  const cvv = document.getElementById("cartaoCvv").value;
  const tipo = document.getElementById("cartaoTipo").value;
  const bandeira = detectarBandeira(numero);

  const erros = { erroCartaoNumero: "", erroCartaoTitular: "", erroCartaoValidade: "", erroCartaoCvv: "" };
  const tamanho = bandeira === "Amex" ? 15 : 16;
  if (numero.length !== tamanho || !luhnValido(numero)) erros.erroCartaoNumero = "Número de cartão inválido.";
  if (titular.length < 3 || !titular.includes(" ")) erros.erroCartaoTitular = "Informe o nome como está no cartão.";
  if (!validadeOk(validade)) erros.erroCartaoValidade = "Validade inválida ou vencida.";
  if (cvv.length !== (bandeira === "Amex" ? 4 : 3)) erros.erroCartaoCvv = bandeira === "Amex" ? "4 dígitos." : "3 dígitos.";

  const final = numero.slice(-4);
  if (!erros.erroCartaoNumero && (c.cartoes || []).some(k => k.final === final && k.bandeira === bandeira && k.validade === validade)){
    erros.erroCartaoNumero = "Esse cartão já está salvo.";
  }

  Object.keys(erros).forEach(id => document.getElementById(id).textContent = erros[id]);
  if (Object.values(erros).some(Boolean)) return;

  // Só bandeira + final + validade: número completo e CVV descartados de propósito.
  if (!c.cartoes) c.cartoes = [];
  const novo = {
    id: "k" + Date.now().toString(36),
    bandeira: bandeira || "Cartão",
    final, titular: titular.toUpperCase(), validade, tipo,
    padrao: c.cartoes.length === 0
  };
  c.cartoes.push(novo);
  salvarClientes();

  modalCartao.classList.remove("is-open");
  renderCliente();
  mostrarToast("Cartão salvo com sucesso.");
  if (aoSalvarCartao){ const cb = aoSalvarCartao; aoSalvarCartao = null; cb(novo); }
});

document.getElementById("closeCartao").addEventListener("click", () => { modalCartao.classList.remove("is-open"); aoSalvarCartao = null; });
document.getElementById("cancelCartao").addEventListener("click", () => { modalCartao.classList.remove("is-open"); aoSalvarCartao = null; });

// ---- PIX (payload no padrão BR Code, com CRC16) ----
function emv(id, valor){ return id + String(valor.length).padStart(2, "0") + valor; }
function crc16(str){
  let crc = 0xFFFF;
  for (let i = 0; i < str.length; i++){
    crc ^= str.charCodeAt(i) << 8;
    for (let b = 0; b < 8; b++){
      crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) : (crc << 1);
      crc &= 0xFFFF;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, "0");
}
function gerarPixCopiaECola(s, valor){
  const conta = emv("00", "br.gov.bcb.pix") + emv("01", PIX_CHAVE_SIMULADA);
  const corpo =
    emv("00", "01") + emv("01", "12") + emv("26", conta) +
    emv("52", "0000") + emv("53", "986") + emv("54", valor.toFixed(2)) +
    emv("58", "BR") + emv("59", "LAUNCHCONTROL OFICINA") + emv("60", "SAO PAULO") +
    emv("62", emv("05", "LC" + s.id)) + "6304";
  return corpo + crc16(corpo);
}
function qrSvg(texto){
  const qr = qrcode(0, "M");
  qr.addData(texto);
  qr.make();
  return qr.createSvgTag({ cellSize: 4, margin: 2, scalable: true, alt: "QR Code PIX" });
}
function copiarTexto(texto){
  if (navigator.clipboard && navigator.clipboard.writeText){
    return navigator.clipboard.writeText(texto);
  }
  return new Promise((ok, falha) => {
    const ta = document.createElement("textarea");
    ta.value = texto; ta.style.position = "fixed"; ta.style.opacity = "0";
    document.body.appendChild(ta); ta.select();
    try { document.execCommand("copy") ? ok() : falha(); } catch(err){ falha(err); }
    ta.remove();
  });
}

// ---- modal: pagamento (cartão | PIX | comprovante) ----
let pagCtx = null; // { id, metodo, cartaoId, parcelas, processando }

function abrirPagamento(id){
  const s = solicitacoes.find(x => x.id === id && sessao && x.clienteId === sessao.cpf);
  if (!s || valorCobranca(s) <= 0) return;
  const cartoes = cartoesDoCliente();
  const padrao = cartoes.find(k => k.padrao) || cartoes[0];
  pagCtx = { id, metodo: "cartao", cartaoId: padrao ? padrao.id : null, parcelas: 1, processando: false };
  renderPagamento();
  modalPagamento.classList.add("is-open");
}

function resumoCobrancaHtml(s){
  return `
    <div class="pay-summary">
      <div>
        <div class="k">${s.veiculo} · ${s.ano}</div>
        <div class="v">${s.orcamento.servico}</div>
      </div>
      <strong class="pay-summary__total">${formatBRL(valorCobranca(s))}</strong>
    </div>`;
}

function metodosAtivos(){
  const m = [];
  if (config.pagamentos.cartao) m.push("cartao");
  if (config.pagamentos.pix) m.push("pix");
  return m.length ? m : ["cartao"];
}

function renderPagamento(){
  if (pagCtx && !estaPago(solicitacoes.find(x => x.id === pagCtx.id) || {}) && !metodosAtivos().includes(pagCtx.metodo)) pagCtx.metodo = metodosAtivos()[0];
  const s = solicitacoes.find(x => x.id === pagCtx.id);
  const corpo = document.getElementById("pagamentoBody");
  if (!s) return;

  const titulo = document.querySelector("#modalPagamento .modal__head h2");
  if (titulo) titulo.textContent = estaPago(s) ? "Comprovante de pagamento" : "Pagamento";

  if (estaPago(s)){
    const p = s.pagamento;
    const cli = clienteAtual();
    corpo.innerHTML = `
      <div class="ticket" id="ticketPagamento">
        <div class="ticket__head">
          <span class="brand-mark">LC</span>
          <div><strong>${config.oficina.nome}</strong><small>Comprovante de pagamento</small></div>
        </div>
        ${(config.oficina.telefone || config.oficina.endereco || config.oficina.email) ? `<div class="ticket__contact">${[config.oficina.endereco, config.oficina.telefone, config.oficina.email].filter(Boolean).join(" · ")}</div>` : ""}
        <div class="ticket__status"><span>✓</span> Pagamento confirmado</div>
        <div class="ticket__total">${formatBRL(p.valor)}</div>
        <dl class="ticket__rows">
          <div><dt>Serviço</dt><dd>${s.orcamento.servico}</dd></div>
          <div><dt>Veículo</dt><dd>${s.veiculo} · ${s.ano}</dd></div>
          ${cli ? `<div><dt>Cliente</dt><dd>${cli.nome}</dd></div>` : ""}
          <div><dt>Forma de pagamento</dt><dd>${rotuloMetodo(p)}</dd></div>
          <div><dt>Data</dt><dd>${p.data}${p.hora ? " às " + p.hora : ""}</dd></div>
          <div><dt>Protocolo</dt><dd class="mono">${p.protocolo}</dd></div>
        </dl>
        <div class="ticket__tear"></div>
        <p class="ticket__foot">Guarde este comprovante. Pagamento simulado — protótipo sem cobrança real.</p>
      </div>
      <div class="modal__actions ticket-actions">
        <button type="button" class="btn btn--outline" id="btnImprimirTicket">Imprimir / salvar PDF</button>
        <button type="button" class="btn btn--primary" id="btnFecharPagamento">Fechar</button>
      </div>
    `;
    document.getElementById("btnFecharPagamento").addEventListener("click", fecharModais);
    document.getElementById("btnImprimirTicket").addEventListener("click", () => {
      document.body.classList.add("imprimindo-ticket");
      const limpar = () => { document.body.classList.remove("imprimindo-ticket"); window.removeEventListener("afterprint", limpar); };
      window.addEventListener("afterprint", limpar);
      window.print();
    });
    return;
  }

  corpo.innerHTML = `
    ${resumoCobrancaHtml(s)}
    ${metodosAtivos().length > 1 ? `
    <div class="segmented" id="payMetodoSeg">
      ${metodosAtivos().map(m => `<button type="button" class="segmented__opt ${pagCtx.metodo === m ? "is-active" : ""}" data-metodo="${m}">${m === "pix" ? "PIX" : "Cartão"}</button>`).join("")}
    </div>` : ""}
    <div id="payMetodoBody"></div>
  `;
  document.querySelectorAll("#payMetodoSeg .segmented__opt").forEach(b => {
    b.addEventListener("click", () => {
      if (pagCtx.processando) return;
      pagCtx.metodo = b.dataset.metodo;
      renderPagamento();
    });
  });
  if (pagCtx.metodo === "pix") renderPagamentoPix(s);
  else renderPagamentoCartao(s);
}

function renderPagamentoCartao(s){
  const alvo = document.getElementById("payMetodoBody");
  const cartoes = cartoesDoCliente();
  const valor = valorCobranca(s);

  if (cartoes.length === 0){
    alvo.innerHTML = `
      <div class="pay-empty">
        <p>Você ainda não tem cartão salvo.</p>
        <button type="button" class="btn btn--primary" id="btnPagCadastrar">Cadastrar cartão</button>
      </div>`;
    document.getElementById("btnPagCadastrar").addEventListener("click", cadastrarCartaoDoPagamento);
    return;
  }

  if (!cartoes.some(k => k.id === pagCtx.cartaoId)) pagCtx.cartaoId = (cartoes.find(k => k.padrao) || cartoes[0]).id;
  const sel = cartoes.find(k => k.id === pagCtx.cartaoId);
  const credito = sel.tipo !== "debito";
  if (!credito || pagCtx.parcelas > maxParcelas()) pagCtx.parcelas = credito ? maxParcelas() : 1;

  const opcoesParcela = Array.from({ length: maxParcelas() }, (_, i) => {
    const n = i + 1;
    return `<option value="${n}" ${pagCtx.parcelas === n ? "selected" : ""}>${n}x de ${formatBRL(valor / n)} ${n === 1 ? "(à vista)" : "sem juros"}</option>`;
  }).join("");

  alvo.innerHTML = `
    <div class="pay-card-list">
      ${cartoes.map(k => `
        <label class="pay-card-opt ${k.id === pagCtx.cartaoId ? "is-selected" : ""}">
          <input type="radio" name="payCartao" value="${k.id}" ${k.id === pagCtx.cartaoId ? "checked" : ""}>
          <span class="pay-card-opt__main">
            <strong>${k.bandeira} •••• ${k.final}</strong>
            <small>${k.tipo === "debito" ? "Débito" : "Crédito"} · vence ${k.validade}</small>
          </span>
          ${k.padrao ? `<span class="saved-card__padrao">Padrão</span>` : ""}
        </label>
      `).join("")}
    </div>
    <button type="button" class="btn-text" id="btnPagOutroCartao">+ Usar outro cartão</button>
    ${credito ? `
      <label class="field" style="margin-bottom:0;">
        Parcelamento
        <select id="payParcelas">${opcoesParcela}</select>
      </label>` : ""}
    <div class="modal__actions">
      <button type="button" class="btn btn--outline" id="btnPagCancelar">Cancelar</button>
      <button type="button" class="btn btn--primary" id="btnPagarCartao">Pagar ${formatBRL(valor)}</button>
    </div>
  `;

  alvo.querySelectorAll('input[name="payCartao"]').forEach(r => {
    r.addEventListener("change", () => { pagCtx.cartaoId = r.value; renderPagamento(); });
  });
  const selParc = document.getElementById("payParcelas");
  if (selParc) selParc.addEventListener("change", () => { pagCtx.parcelas = Number(selParc.value); });
  document.getElementById("btnPagOutroCartao").addEventListener("click", cadastrarCartaoDoPagamento);
  document.getElementById("btnPagCancelar").addEventListener("click", fecharModais);
  document.getElementById("btnPagarCartao").addEventListener("click", () => pagarComCartao(s));
}

function cadastrarCartaoDoPagamento(){
  const id = pagCtx.id;
  modalPagamento.classList.remove("is-open");
  abrirModalCartao((novo) => {
    // volta para o pagamento já com o cartão novo selecionado
    pagCtx = { id, metodo: "cartao", cartaoId: novo.id, parcelas: 1, processando: false };
    renderPagamento();
    modalPagamento.classList.add("is-open");
  });
}

function pagarComCartao(s){
  if (pagCtx.processando) return;
  const k = cartoesDoCliente().find(x => x.id === pagCtx.cartaoId);
  if (!k) return;
  pagCtx.processando = true;
  const btn = document.getElementById("btnPagarCartao");
  btn.disabled = true;
  btn.textContent = "Processando…";
  const parcelas = k.tipo === "debito" ? 1 : Math.min(pagCtx.parcelas, maxParcelas());
  setTimeout(() => {
    confirmarPagamento(s, "cartao", {
      cartao: { bandeira: k.bandeira, final: k.final, tipo: k.tipo },
      parcelas
    });
  }, 1200);
}

function renderPagamentoPix(s){
  const alvo = document.getElementById("payMetodoBody");
  const codigo = gerarPixCopiaECola(s, valorCobranca(s));
  alvo.innerHTML = `
    <div class="pix-box">
      <div class="pix-box__qr">${qrSvg(codigo)}</div>
      <div class="pix-box__info">
        <p class="pix-box__title">Escaneie com o app do seu banco</p>
        <p class="pix-box__sub">Ou use o PIX copia e cola abaixo. O código vale por 30 minutos.</p>
        <textarea id="pixCodigo" class="pix-box__code" rows="4" readonly>${codigo}</textarea>
        <button type="button" class="btn btn--outline btn--small" id="btnCopiarPix">Copiar código</button>
      </div>
    </div>
    <div class="sim-note">
      <strong>Modo protótipo</strong>
      <span>Este QR não gera cobrança real e nenhum banco está conectado. Use o botão para simular o PIX recebido.</span>
    </div>
    <div class="modal__actions">
      <button type="button" class="btn btn--outline" id="btnPagCancelar">Cancelar</button>
      <button type="button" class="btn btn--primary" id="btnSimularPix">Simular pagamento recebido</button>
    </div>
  `;
  document.getElementById("btnCopiarPix").addEventListener("click", () => {
    copiarTexto(codigo)
      .then(() => mostrarToast("Código PIX copiado."))
      .catch(() => { document.getElementById("pixCodigo").select(); mostrarToast("Selecione e copie o código manualmente."); });
  });
  document.getElementById("btnPagCancelar").addEventListener("click", fecharModais);
  document.getElementById("btnSimularPix").addEventListener("click", () => {
    if (pagCtx.processando) return;
    pagCtx.processando = true;
    const b = document.getElementById("btnSimularPix");
    b.disabled = true; b.textContent = "Confirmando…";
    setTimeout(() => confirmarPagamento(s, "pix", {}), 900);
  });
}

function confirmarPagamento(s, metodo, extra){
  // Futuro: aqui entra a resposta do gateway / webhook do PSP.
  s.pagamento = Object.assign({
    status: "pago",
    metodo,
    valor: valorCobranca(s),
    data: new Date().toLocaleDateString("pt-BR"),
    hora: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
    protocolo: "LC-" + s.id + "-" + Date.now().toString(36).toUpperCase()
  }, extra);
  notificarCompra(s, `pagamento-${s.id}-${s.pagamento.protocolo}`, "Pagamento confirmado!", "Aprovado");
  salvarSolicitacoes();
  if (pagCtx) pagCtx.processando = false;
  renderCliente();
  renderAll();
  renderPagamento();
  mostrarToast("Pagamento confirmado! A oficina foi notificada.");
}

document.getElementById("closePagamento").addEventListener("click", fecharModais);

// =========================================================
// 13. TOAST

// =========================================================
let toastTimer = null;
function mostrarToast(msg){
  const toast = document.getElementById("toast");
  toast.textContent = msg;
  toast.classList.add("is-visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("is-visible"), 3200);
}

// =========================================================
// 14. UTILITÁRIOS
// =========================================================
function escapeAttr(str){
  return String(str == null ? "" : str).replace(/"/g, "&quot;");
}

// =========================================================
// 15. AÇÕES DIVERSAS (mockadas)
// =========================================================
document.getElementById("btnNotif").addEventListener("click", () => goToView("notificacoes"));
const btnNotifCliente = document.getElementById("btnNotifCliente");
if(btnNotifCliente) btnNotifCliente.addEventListener("click",()=>goToViewCli("notificacoes"));


// =========================================================
// 17. MELHORIAS FUNCIONAIS — fluxo cliente/oficina
// Persistência local do protótipo. Em produção, migrar para API
// autenticada e banco transacional (ver README atualizado).
// =========================================================
function hojeBR(){ return new Date().toLocaleDateString("pt-BR"); }
function novoId(){ return Date.now() + Math.floor(Math.random()*1000); }
function notificarClienteDaSolicitacao(s, titulo, mensagem, evento){
  criarNotificacao({destinatario:`cliente:${s.clienteId}`,tipo:"cliente",titulo,mensagem,solicitacaoId:s.id,evento});
}
function notificarOficinasDaSolicitacao(s, titulo, mensagem, evento){
  // A conta oficina deste protótipo representa uma única oficina compartilhada.
  const oficina = oficinaLogada();
  if (oficina) criarNotificacao({destinatario:`oficina:${oficina.cpf}`,tipo:"oficina",titulo,mensagem,solicitacaoId:s.id,evento});
}
function montarFormularioCliente(){
  const sec = document.getElementById("viewcli-solicitacoes");
  if (!sec || document.getElementById("lcNovaSolicitacao")) return;
  const form = document.createElement("div");
  form.className="panel";
  form.id="lcNovaSolicitacao";
  form.style.marginBottom="18px";
  form.innerHTML=`<div class="panel__head"><h2>Nova solicitação de serviço</h2></div>
  <form id="lcFormSolicitacao" class="form-grid">
    <div class="form-row"><label>Veículo cadastrado<select id="lcSolicVeiculo" required></select></label></div>
    <div class="form-row"><label>Serviço desejado<input id="lcSolicServico" required maxlength="100" placeholder="Ex.: revisão, freios, suspensão"></label></div>
    <div class="form-row"><label>Quilometragem atual<input id="lcSolicKm" required maxlength="30" placeholder="Ex.: 45.000 km"></label></div>
    <div class="form-row"><label>Descreva o problema<textarea id="lcSolicDescricao" rows="3" required maxlength="1000" placeholder="Conte os sintomas e quando começaram"></textarea></label></div>
    <button class="btn btn--primary" type="submit">Enviar solicitação à oficina</button>
    <p class="field-error" id="lcSolicErro" role="alert"></p>
  </form>`;
  sec.insertBefore(form,sec.querySelector(".panel"));
  document.getElementById("lcFormSolicitacao").addEventListener("submit",e=>{
    e.preventDefault();
    const c=clienteAtual(); if(!c) return;
    const veiculo=c.veiculos.find(v=>v.placa===document.getElementById("lcSolicVeiculo").value);
    const servico=document.getElementById("lcSolicServico").value.trim();
    const km=document.getElementById("lcSolicKm").value.trim();
    const descricao=document.getElementById("lcSolicDescricao").value.trim();
    if(!veiculo || !servico || !km || !descricao){document.getElementById("lcSolicErro").textContent="Preencha todos os campos e selecione um veículo.";return;}
    const s={id:novoId(),clienteId:c.cpf,cliente:c.nome,telefone:c.telefone||"",veiculo:veiculo.modelo,placa:veiculo.placa,ano:Number(veiculo.ano),km,servico,descricao,data:hojeBR(),dataISO:new Date().toISOString(),fotos:0,fotosData:[],status:"aguardando",orcamento:null,entrada:null,previsao:null,historico:[{status:"aguardando",data:new Date().toISOString(),ator:"cliente",descricao:"Solicitação criada pelo cliente"}]};
    solicitacoes.unshift(s); salvarSolicitacoes();
    const of=oficinas[0];
    if(of) criarNotificacao({destinatario:`oficina:${of.cpf}`,tipo:"oficina",titulo:"Nova solicitação recebida",mensagem:`${c.nome} • ${veiculo.modelo} • ${servico} • Pedido LC-${s.id}`,solicitacaoId:s.id,event:"solicitacao-"+s.id});
    e.target.reset(); renderCliente(); renderAll(); montarFormularioCliente(); popularVeiculosSolicitacao();
    mostrarToast("Solicitação enviada. A oficina foi notificada.");
  });
  popularVeiculosSolicitacao();
}
function popularVeiculosSolicitacao(){
  const sel=document.getElementById("lcSolicVeiculo"), c=clienteAtual(); if(!sel||!c)return;
  sel.innerHTML=(c.veiculos||[]).map(v=>`<option value="${escapeAttr(v.placa)}">${escapeHtml(v.modelo)} · ${v.ano} · ${escapeHtml(v.placa)}</option>`).join("");
  if(!c.veiculos.length) sel.innerHTML='<option value="">Cadastre um veículo antes de solicitar</option>';
  const btn=document.querySelector('#lcFormSolicitacao button[type="submit"]'); if(btn)btn.disabled=!c.veiculos.length;
}
function montarCadastroVeiculo(){
  const sec=document.getElementById("viewcli-veiculos"); if(!sec||document.getElementById("lcNovoVeiculo"))return;
  const box=document.createElement("div");box.className="panel";box.id="lcNovoVeiculo";box.style.marginBottom="18px";
  box.innerHTML=`<div class="panel__head"><h2>Adicionar veículo à garagem</h2></div>
  <form id="lcFormVeiculo" class="form-row" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px">
  <label>Modelo<input id="lcVModelo" required maxlength="70"></label><label>Ano<input id="lcVAno" type="number" min="1950" max="2100" required></label><label>Placa<input id="lcVPlaca" required maxlength="7"></label><label>Quilometragem<input id="lcVKm" placeholder="Ex.: 35.000 km" required></label><button class="btn btn--primary" type="submit">Salvar veículo</button></form>`;
  sec.insertBefore(box,sec.querySelector("#cliVeiculosCards"));
  document.getElementById("lcFormVeiculo").addEventListener("submit",e=>{
    e.preventDefault();const c=clienteAtual();if(!c)return;
    const modelo=document.getElementById("lcVModelo").value.trim(),ano=Number(document.getElementById("lcVAno").value),placa=document.getElementById("lcVPlaca").value.toUpperCase().replace(/[^A-Z0-9]/g,""),km=document.getElementById("lcVKm").value.trim();
    if(!modelo||!Number.isInteger(ano)||ano<1950||ano>new Date().getFullYear()+1||!/^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$/.test(placa)){mostrarToast("Confira modelo, ano e placa (padrão ABC1D23).");return;}
    if(clientes.some(x=>(x.veiculos||[]).some(v=>v.placa===placa))){mostrarToast("Esta placa já está cadastrada.");return;}
    c.veiculos=c.veiculos||[];c.veiculos.push({modelo,ano,placa,km});salvarClientes();renderCliente();popularVeiculosSolicitacao();mostrarToast("Veículo adicionado à garagem.");
  });
}
function registrarHistorico(s,status,ator,descricao){
  s.historico=s.historico||[];s.historico.push({status,data:new Date().toISOString(),ator,descricao});
}
function renderHistorico(s){
  const hist=(s.historico||[]).slice().sort((a,b)=>new Date(a.data)-new Date(b.data));
  return hist.length?`<div class="panel" style="margin-top:14px;padding:14px"><h3>Histórico de atualizações</h3>${hist.map(h=>`<p style="margin:8px 0"><strong>${escapeHtml(STATUS_INFO[h.status]?.label||h.status)}</strong> · ${new Date(h.data).toLocaleString("pt-BR")}<br><small>${escapeHtml(h.descricao||"Atualização")} — ${escapeHtml(h.ator||"sistema")}</small></p>`).join("")}</div>`:"";
}
function atualizarStatusServico(id,proximo){
  const s=solicitacoes.find(x=>x.id===id);if(!s||!sessao||sessao.tipo!=="oficina")return;
  if(proximo==="execucao"&&!["aprovado","aprovado_parcial"].includes(s.status)){mostrarToast("Só é possível iniciar um serviço aprovado.");return;}
  if(proximo==="concluido"&&s.status!=="execucao"){mostrarToast("Inicie o serviço antes de concluí-lo.");return;}
  s.status=proximo;
  if(proximo==="execucao")s.entrada=hojeBR();
  if(proximo==="concluido"){s.conclusao=hojeBR();s.laudo=s.laudo||"";}
  registrarHistorico(s,proximo,"oficina",proximo==="execucao"?"Oficina iniciou a execução":"Oficina concluiu o serviço");
  salvarSolicitacoes();
  notificarClienteDaSolicitacao(s,proximo==="execucao"?"Serviço iniciado":"Serviço concluído",`${s.veiculo} • ${s.orcamento?.servico||s.servico} • ${STATUS_INFO[proximo].label}`,`status-${id}-${proximo}`);
  renderAll();renderCliente();abrirDetalhe(id);mostrarToast("Etapa do serviço atualizada e cliente notificado.");
}
function compararOrcamentosCliente(){
  const c=clienteAtual();if(!c)return;
  const propostas=solicitacoes.filter(s=>s.clienteId===c.cpf&&s.orcamento&&["aprovacao","aprovado","aprovado_parcial","execucao","concluido"].includes(s.status));
  const alvo=document.getElementById("viewcli-orcamentos");if(!alvo||document.getElementById("lcComparador"))return;
  const box=document.createElement("div");box.className="panel";box.id="lcComparador";box.style.marginBottom="18px";
  box.innerHTML=`<div class="panel__head"><h2>Comparar propostas recebidas</h2></div><p>Compare valores e prazos das propostas disponíveis. A decisão continua sendo sua.</p><div class="table-wrap"><table class="data-table"><thead><tr><th>Veículo</th><th>Proposta</th><th>Peças</th><th>Mão de obra</th><th>Total</th><th>Prazo</th><th>Status</th></tr></thead><tbody>${propostas.length?propostas.map(s=>`<tr><td>${escapeHtml(s.veiculo)}</td><td>${escapeHtml(s.orcamento.servico)}</td><td>${formatBRL(s.orcamento.subtotalPecas||0)}</td><td>${formatBRL(s.orcamento.subtotalMaoDeObra||0)}</td><td>${formatBRL(s.orcamento.total)}</td><td>${escapeHtml(s.orcamento.prazo||"—")}</td><td>${statusBadge(s.status)}</td></tr>`).join(""):'<tr><td colspan="7">Nenhuma proposta disponível para comparação.</td></tr>'}</tbody></table></div>`;
  if(propostas.length){
    const menor=propostas.reduce((a,b)=>a.orcamento.total<=b.orcamento.total?a:b);
    box.insertAdjacentHTML("beforeend",`<p style="margin-top:12px"><strong>Menor valor:</strong> ${escapeHtml(menor.orcamento.servico)} (${formatBRL(menor.orcamento.total)}). Os prazos são exibidos como informados pela oficina e não são comparados numericamente.</p>`);
  }
  alvo.insertBefore(box,alvo.firstChild);
}
function avaliarServico(id,nota,comentario){
  const s=solicitacoes.find(x=>x.id===id&&sessao&&x.clienteId===sessao.cpf);
  if(!s||s.status!=="concluido"||s.avaliacao){mostrarToast("Avaliação indisponível ou já registrada.");return;}
  if(nota<1||nota>5||!Number.isInteger(nota)){mostrarToast("Selecione uma nota de 1 a 5.");return;}
  s.avaliacao={nota,comentario:comentario.trim(),data:new Date().toISOString(),clienteId:sessao.cpf};
  registrarHistorico(s,s.status,"cliente",`Cliente avaliou o serviço com ${nota}/5`);
  salvarSolicitacoes();renderCliente();renderAll();mostrarToast("Avaliação registrada. Obrigado!");
}
function instalarMelhoriasLaunchControl(){
  montarFormularioCliente();montarCadastroVeiculo();compararOrcamentosCliente();
  const detalheBase=abrirDetalhe;
  abrirDetalhe=function(id){
    detalheBase(id);
    const s=solicitacoes.find(x=>x.id===id);if(!s||!sessao||sessao.tipo!=="oficina")return;
    const body=document.getElementById("detalheBody");
    const actions=body.querySelector(".modal__actions");
    if(actions){
      if(["aprovado","aprovado_parcial"].includes(s.status)) actions.insertAdjacentHTML("beforeend",`<button type="button" class="btn btn--primary" id="lcIniciarServico">Iniciar serviço</button>`);
      if(s.status==="execucao") actions.insertAdjacentHTML("beforeend",`<button type="button" class="btn btn--primary" id="lcConcluirServico">Concluir serviço</button>`);
      if(s.status==="concluido") actions.insertAdjacentHTML("beforeend",`<div class="detail-item full"><label>Laudo técnico<textarea id="lcLaudo" rows="3" maxlength="2000" placeholder="Descreva diagnóstico, procedimentos e recomendações">${escapeHtml(s.laudo||"")}</textarea></label><button type="button" class="btn btn--outline" id="lcSalvarLaudo">Salvar laudo</button></div>`);
      const ini=document.getElementById("lcIniciarServico"),fim=document.getElementById("lcConcluirServico"),laudo=document.getElementById("lcSalvarLaudo");
      if(ini)ini.onclick=()=>atualizarStatusServico(id,"execucao");
      if(fim)fim.onclick=()=>atualizarStatusServico(id,"concluido");
      if(laudo)laudo.onclick=()=>{s.laudo=document.getElementById("lcLaudo").value.trim();s.laudoData=new Date().toISOString();registrarHistorico(s,s.status,"oficina","Laudo técnico atualizado");salvarSolicitacoes();notificarClienteDaSolicitacao(s,"Laudo técnico disponível",`O laudo do serviço ${s.orcamento?.servico||s.servico} foi atualizado.`,`laudo-${id}-${s.laudoData}`);mostrarToast("Laudo salvo e cliente notificado.");};
    }
    body.insertAdjacentHTML("beforeend",renderHistorico(s));
  };
  const abrirCliBase=abrirDetalheCliente;
  abrirDetalheCliente=function(id){
    abrirCliBase(id);
    const s=solicitacoes.find(x=>x.id===id&&sessao&&x.clienteId===sessao.cpf);if(!s)return;
    const body=document.getElementById("detalheCliBody");
    body.insertAdjacentHTML("beforeend",s.laudo?`<div class="detail-item full"><div class="k">Laudo técnico · ${s.laudoData?new Date(s.laudoData).toLocaleString("pt-BR"):""}</div><div class="v">${escapeHtml(s.laudo)}</div></div>`:"");
    body.insertAdjacentHTML("beforeend",renderHistorico(s));
    if(s.status==="concluido"){
      const review=document.createElement("div");review.className="panel";review.style.marginTop="14px";
      review.innerHTML=s.avaliacao?`<strong>Sua avaliação: ${s.avaliacao.nota}/5</strong><p>${escapeHtml(s.avaliacao.comentario)}</p>`:`<h3>Avaliar serviço</h3><form id="lcFormAvaliacao"><label>Nota<select id="lcNota"><option value="5">5 — Excelente</option><option value="4">4 — Muito bom</option><option value="3">3 — Bom</option><option value="2">2 — Regular</option><option value="1">1 — Ruim</option></select></label><label>Comentário<textarea id="lcComentario" rows="2" maxlength="500"></textarea></label><button class="btn btn--primary" type="submit">Enviar avaliação</button></form>`;
      body.appendChild(review);
      const form=document.getElementById("lcFormAvaliacao");if(form)form.onsubmit=e=>{e.preventDefault();avaliarServico(id,Number(document.getElementById("lcNota").value),document.getElementById("lcComentario").value);fecharModais();};
    }
  };
}
// Atualiza histórico e garante que cliente/officina vejam estados sincronizados.
const renderClienteBase=renderCliente;
renderCliente=function(){renderClienteBase();if(sessao?.tipo==="cliente"){montarFormularioCliente();montarCadastroVeiculo();compararOrcamentosCliente();}};

// =========================================================
// 16. INICIALIZAÇÃO
// =========================================================
carregarEstado();
restaurarSessaoSeExistir();
renderAll();
instalarMelhoriasLaunchControl();
