/* Cliente HTTP do backend Java. Uso: LaunchControlAPI.login(email, senha), .get(path), .post(path, body), .put(path, body). */
(function(){
 const BASE=window.LAUNCHCONTROL_API_URL||"http://localhost:8080/api";
 let credentials=sessionStorage.getItem("lc_api_auth")||"";
 async function request(path,method="GET",body){
  const headers={"Content-Type":"application/json"};if(credentials)headers.Authorization="Basic "+credentials;
  const response=await fetch(BASE+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body)});
  const data=response.status===204?null:await response.json().catch(()=>({}));
  if(!response.ok)throw new Error(data.message||data.detail||"Falha na comunicação com o servidor.");
  return data;
 }
 window.LaunchControlAPI={
  async login(email,senha){credentials=btoa(unescape(encodeURIComponent(email+":"+senha)));sessionStorage.setItem("lc_api_auth",credentials);try{return await request("/me");}catch(e){credentials="";sessionStorage.removeItem("lc_api_auth");throw e;}},
  logout(){credentials="";sessionStorage.removeItem("lc_api_auth");},
  get(path){return request(path);},post(path,body){return request(path,"POST",body);},put(path,body){return request(path,"PUT",body);},
  async cadastro(dados){return request("/public/cadastro","POST",dados);}
 };
})();